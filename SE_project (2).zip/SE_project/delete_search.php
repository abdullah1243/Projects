<?php
    $bookname = $_POST['bookname'];

    $conn = new mysqli('localhost', 'root', '', 'SE_project');
    if($conn->connect_error)
    {
        echo '  <script> 
                    location.replace("http://127.0.0.1:5500/delete.html?success=0");
                </script>';
    }
    else
    {
        $sel = $conn->prepare("SELECT book_name, author, edition FROM books WHERE book_name = ?");
        $sel->bind_param("s", $bookname);
        $sel->execute();
        $res = $sel->get_result();

        if($res->num_rows > 0)
        {
            $row = $res->fetch_assoc();
            $author = $row['author'];
            $edition = $row['edition'];

            echo '  <script> 
                        location.replace("http://127.0.0.1:5500/delete.html?success=1&book_name='.$bookname.'&author='.$author.'&edition='.$edition.'");
                    </script>';
        }
        else
        {
            echo '  <script> 
                        location.replace("http://127.0.0.1:5500/delete.html?success=2");
                    </script>';
        }
    }
?>