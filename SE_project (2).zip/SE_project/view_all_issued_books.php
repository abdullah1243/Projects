<?php

    $conn = new mysqli('localhost', 'root', '', 'SE_project');
    if($conn->connect_error)
    {
        echo '  <script> 
                    location.replace("http://127.0.0.1:5500/view_all_issued_books.html?success=0");
                </script>';
    }
    else
    {
        $sel = $conn->prepare("SELECT * from issued, books, user where issued.book_id = books.book_id and user.user_id = issued.user_id ");
        $sel->execute();

        $res = $sel->get_result();

        $a = '  <script> 
                        location.replace("http://127.0.0.1:5500/view_all_issued_books.html?success=1';
        $b = '");
        </script>';
        $iter = 1;

        while($data = $res->fetch_assoc())
        {
            $issue_date = $data['issue_date'];
            $due_date = $data['due_date'];
            $book_name = $data['book_name'];
            $author = $data['author'];
            $edition = $data['edition'];
            $publisher = $data['publisher'];
            $category = $data['category'];
            $email = $data['email'];

    
            $a = $a.'&book_name'.$iter.'='.$book_name.'&author'.$iter.'='.$author.'&edition'.$iter.'='.$edition.
            '&publisher'.$iter.'='.$publisher.'&category'.$iter.'='.$category.'&issue_date'.$iter.'='.$issue_date.
            '&due_date'.$iter.'='.$due_date.'&user'.$iter.'='.$email;
    
            $iter = $iter + 1;
        }

        $a = $a.$b;

        echo $a;
    }
?>