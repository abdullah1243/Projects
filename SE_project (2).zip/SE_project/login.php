<html>
    <head>

    </head>
    <body>

        <?php
            $username = $_POST['username'];
            $password = $_POST['password'];
            $check = $_POST['checkbox'];
            
            $conn = new mysqli('localhost', 'root', '', 'SE_project');
            if($conn->connect_error)
            {
                echo '  <script> 
                            location.replace("http://127.0.0.1:5500/login.html?success=0");
                        </script>';
            }
            else
            {
                if($check == "user")
                {
                    $sql = $conn->prepare("SELECT * from user WHERE email = ? and passw = ?");
                    $sql->bind_param("ss", $username, $password);
                    $sql->execute();
                    $res = $sql->get_result();
                    
                    if($res->num_rows > 0)
                    {
                        $data = $res->fetch_assoc();
                        echo '  <script>
                                    location.replace("http://127.0.0.1:5500/userhome.html?user=1&admin=0&userid='.$data['user_id'].'&adminid=-1");
                                </script>';
                    }
                    else
                    {
                        echo '  <script> 
                                    location.replace("http://127.0.0.1:5500/login.html?success=2");
                                </script>';
                    }
                }
                else if($check == "admin")
                {
                    $sql = $conn->prepare("SELECT * from admin WHERE email = ? and passw = ?");
                    $sql->bind_param("ss", $username, $password);
                    $sql->execute();
                    $res = $sql->get_result();
                    
                    if($res->num_rows > 0)
                    {
                        $data = $res->fetch_assoc();
                        echo '  <script>
                                    location.replace("http://127.0.0.1:5500/adminhome.html?user=0&admin=1&userid=-1&adminid='.$data['admin_id'].'");
                                </script>';
                    }
                    else
                    {
                        echo '  <script> 
                                    location.replace("http://127.0.0.1:5500/login.html?success=2");
                                </script>';
                    }
                }
            }
        ?>

        <script>
            
        </script>
    </body>
</html>