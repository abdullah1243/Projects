<?php
    $bookname = $_POST['bookname'];

    $conn = new mysqli('localhost', 'root', '', 'SE_project');
    if($conn->connect_error)
    {
        echo '  <script> 
                    location.replace("http://127.0.0.1:5500/delete.html?success=0");
                </script>';
    }
    else
    {
        $sel = $conn->prepare("DELETE FROM books WHERE book_name = ?");
        $sel->bind_param("s", $bookname);
        $sel->execute();
        if($sel->affected_rows > 0)
        {
            echo '  <script>
                        location.replace("http://127.0.0.1:5500/delete.html?success=3");
                    </script>';
        }
        else
        {
            echo '  <script> 
                        console.log('.$bookname.');
                        location.replace("http://127.0.0.1:5500/delete.html?success=2");
                    </script>';
        }

    }