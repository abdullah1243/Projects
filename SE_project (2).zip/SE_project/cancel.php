<?php
    $book_name = $_GET['book_name'];
    $user_id = $_GET['user_id'];
    settype($user_id, "integer");

    $conn = new mysqli('localhost', 'root', '', 'SE_project');
    if($conn->connect_error)
    {
        echo '  <script> 
                    location.replace("http://127.0.0.1:5500/viewissuedbooks.html?success=0");
                </script>';
    }
    else
    {
        $sel = $conn->prepare("SELECT * from books where book_name = ?");
        $sel->bind_param("s", $book_name);
        $sel->execute();

        $res = $sel->get_result();
        $data = $res->fetch_assoc();

        $book_id = $data['book_id'];
        settype($book_id, "integer");
        
        $sel->close();

        $sql = $conn->prepare("DELETE FROM issued WHERE book_id = ? and user_id = ?");
        $sql->bind_param("ii", $book_id, $user_id);
        $sql->execute();

        $sql->close();

        $upd = $conn->prepare("UPDATE books SET no_of_copies = no_of_copies + 1 WHERE book_id = ?");
        $upd->bind_param("i", $book_id);
        $upd->execute();
    }
?>