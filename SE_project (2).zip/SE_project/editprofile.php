<?php
    $userid = $_POST['user_id'];
    settype($userid, "integer");
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $phonenumber = $_POST['phonenumber'];
    $dob = $_POST['dob'];
    $address = $_POST['address'];
    $password = $_POST['password'];
    $gender = $_POST['gender'];

    $conn = new mysqli('localhost', 'root', '', 'SE_project');
    if($conn->connect_error)
    {
        echo '  <script> 
                    location.replace("http://127.0.0.1:5500/editprofile.html?success=0");
                </script>';
    }
    else
    {
        $sel = $conn->prepare("SELECT * from user where user_id = ?");
        $sel->bind_param("i", $userid);
        $sel->execute();

        $res = $sel->get_result();
        $data = $res->fetch_assoc();

        if($fname == "")
            $fname = $data['first_name'];
        
        if($lname == "")
            $lname = $data['last_name'];

        if($phonenumber == "")
            $phonenumber = $data['phone_number'];

        if($dob == "")
            $dob = $data['dob'];

        if($address == "")
            $address = $data['address'];

        if($password == "")
            $password = $data['passw'];

        if($gender == "")
            $gender = $data['gender'];

        $sql = $conn->prepare("UPDATE user SET first_name = ?, last_name = ?, phone_number = ?, dob = ?, address = ?, passw = ?, gender = ? WHERE user_id = ?");
        $sql->bind_param("sssssssi", $fname, $lname, $phonenumber, $dob, $address, $password, $gender, $userid);
        $sql->execute();
        echo '  <script> 
                    console.log("'.$userid.'");
                </script>';
        if($sql->affected_rows > 0)
        {
            echo '  <script> 
                        location.replace("http://127.0.0.1:5500/editprofile.html?success=1");
                    </script>';
        }
        else
        {
            echo '  <script> 
                        location.replace("http://127.0.0.1:5500/editprofile.html?success=2");
                    </script>';
        }
    }
?>