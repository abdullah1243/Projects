<?php

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $question = $_POST['question'];

    $conn = new mysqli('localhost', 'root', '', 'SE_project');
    if($conn->connect_error)
    {
        echo '  <script> 
                    location.replace("http://127.0.0.1:5500/recoverpassword.html?success=0");
                </script>';
    }
    else
    {
        $sel = $conn->prepare("SELECT * FROM user WHERE email = ? and question = ?");
        $sel->bind_param("ss", $email, $question);
        $sel->execute();
        $res = $sel->get_result();

        if($res->num_rows > 0)
        {
            $data = $res->fetch_assoc();
            $pass = $data['passw'];
            echo '  <script> 
                        location.replace("http://127.0.0.1:5500/recoverpassword.html?success=1&passw='.$pass.'");
                    </script>';
        }
        else
        {
            echo '  <script> 
                        location.replace("http://127.0.0.1:5500/recoverpassword.html?success=2");
                    </script>';
        }
    }

    $conn->close();

?>