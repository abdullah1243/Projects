<?php
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $phonenumber = $_POST['phonenumber'];
    $dob = $_POST['dob'];
    $cnic = $_POST['cnic'];
    $address = $_POST['address'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $gender = $_POST['gender'];
    $question = $_POST['securityquestion'];

    $conn = new mysqli('localhost', 'root', '', 'SE_project');
    if($conn->connect_error)
    {
        echo '  <script> 
                    location.replace("http://127.0.0.1:5500/signup.html?success=0");
                </script>';
    }
    else
    {
        $sel = $conn->prepare("SELECT * from user WHERE email = ?");
        $sel->bind_param("s", $email);
        $sel->execute();
        $res = $sel->get_result();

        if($res->num_rows > 0)
        {
            $sel->close();
            echo '  <script> 
                        location.replace("http://127.0.0.1:5500/signup.html?success=2");
                    </script>';
        }
        else
        {
            $sel->close();
            $sql = $conn->prepare("INSERT INTO user(first_name, last_name, phone_number, dob, cnic, address, email, passw, gender, question)
                                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    
            $sql->bind_param("ssssssssss", $fname, $lname, $phonenumber, $dob, $cnic, $address, $email, $password, $gender, $question);
            $sql->execute();
            $sql->close();
            echo '  <script> 
                        location.replace("http://127.0.0.1:5500/login.html");
                    </script>';
        }
    }

    $conn->close();

?>