<?php

    $conn = new mysqli('localhost', 'root', '', 'SE_project');
    if($conn->connect_error)
    {
        echo '  <script> 
                    location.replace("http://127.0.0.1:5500/view_all_books_admin.html?success=0");
                </script>';
    }
    else
    {
        $sel = $conn->prepare("SELECT * from books");
        $sel->execute();

        $res = $sel->get_result();

        $a = '  <script> 
                        location.replace("http://127.0.0.1:5500/view_all_books_admin.html?success=1';
        $b = '");
        </script>';
        $iter = 1;

        while($data = $res->fetch_assoc())
        {
            $book_name = $data['book_name'];
            $author = $data['author'];
            $edition = $data['edition'];
            $publisher = $data['publisher'];
            $category = $data['category'];
            $number_of_copies = $data['no_of_copies'];
            $year_of_release = $data['year_of_release'];
    
            $a = $a.'&book_name'.$iter.'='.$book_name.'&author'.$iter.'='.$author.'&edition'.$iter.'='.$edition.
            '&publisher'.$iter.'='.$publisher.'&category'.$iter.'='.$category.'&number_of_books'.$iter.'='.$number_of_copies.
            '&year_of_release'.$iter.'='.$year_of_release;
    
            $iter = $iter + 1;
        }

        $a = $a.$b;

        echo $a;
    }
?>