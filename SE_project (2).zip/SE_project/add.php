
<?php

    $bookname = $_POST['bookname'];
    $no_of_copies = $_POST['no_of_copies'];
    $release_year = $_POST['release_year'];
    $author = $_POST['author'];
    $publisher = $_POST['publisher'];
    $edition = $_POST['edition'];
    $catagory = $_POST['catagory'];

    echo '  <script> 
                console.log("'.$release_year.'");
            </script>';

    $conn = new mysqli('localhost', 'root', '', 'SE_project');
    if($conn->connect_error)
    {
        echo '  <script> 
                    location.replace("http://127.0.0.1:5500/add.html?success=0");
                </script>';
    }
    else
    {
        $sel = $conn->prepare("SELECT * FROM books WHERE book_name = ? and edition = ?");
        $sel->bind_param("ss", $bookname, $edition);
        $sel->execute();
        $res = $sel->get_result();

        if($res->num_rows > 0)
        {
            $row = $res->fetch_assoc();
            $numbook = $row['no_of_copies'];
            $numbook += $no_of_copies;
            $sel->close();

            $up = $conn->prepare("UPDATE books SET no_of_copies = ? WHERE book_name = ? and edition = ?");
            $up->bind_param("iss", $numbook, $bookname, $edition);
            $up->execute();
            echo '  <script> 
                        location.replace("http://127.0.0.1:5500/add.html?success=1");
                    </script>';
            $up->close();
        }
        else
        {
            $sel->close();
            $sql = $conn->prepare("INSERT INTO books(book_name, no_of_copies, edition, author, year_of_release, publisher, category)
                                    VALUES (?, ?, ?, ?, ?, ?, ?)");
    
            $sql->bind_param("sisssss", $bookname, $no_of_copies, $edition, $author, $release_year, $publisher, $catagory);
            $sql->execute();
            echo '  <script> 
                        location.replace("http://127.0.0.1:5500/add.html?success=1");
                    </script>';
        }
    }

    $conn->close();

?>