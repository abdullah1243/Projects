<?php
    $user_id = $_POST['user_id'];
    settype($user_id, "integer");
    $bookname = $_POST['bookname'];
    $author = $_POST['author'];
    $edition = $_POST['edition'];
    $issuedate = $_POST['issuedate'];
    $due_date = $_POST['due_date'];

    $conn = new mysqli('localhost', 'root', '', 'SE_project');
    if($conn->connect_error)
    {
        echo '  <script> 
                    location.replace("http://127.0.0.1:5500/issue.html?success=0");
                </script>';
    }
    else
    {
        $sel = $conn->prepare("UPDATE books SET no_of_copies = no_of_copies - 1 WHERE book_name = ?");
        $sel->bind_param("s", $bookname);
        $sel->execute();
        if($sel->affected_rows > 0)
        {
            $sel->close();
            $sql = $conn->prepare("SELECT book_id from books WHERE book_name = ?");
            $sql->bind_param("s", $bookname);
            $sql->execute();
            $res = $sql->get_result();
            $data = $res->fetch_assoc();
            $book_id = $data['book_id'];
            echo '  <script>
                        console.log("'.$book_id.'");
                    </script>';
            $sql->close();

            $issue = $conn->prepare("INSERT INTO issued(book_id, user_id, issue_date, due_date)
            VALUES (?, ?, ?, ?)");
            $issue->bind_param("iiss", $book_id, $user_id, $issuedate, $due_date);
            $issue->execute();

            echo '  <script>
                        console.log("'.$issue->error.'");
                    </script>';

            if($issue->affected_rows > 0)
            {
                echo '  <script>
                            location.replace("http://127.0.0.1:5500/issue.html?success=3");
                        </script>';
            }
            else
            {
                echo '  <script>
                            location.replace("http://127.0.0.1:5500/issue.html?success=2");
                        </script>';
            }
        }
        else
        {
            echo '  <script> 
                        console.log('.$bookname.');
                        location.replace("http://127.0.0.1:5500/issue.html?success=2");
                    </script>';
        }

    }
?>