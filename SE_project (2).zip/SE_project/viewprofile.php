<?php
    $user_id = $_POST['user_id'];
    settype($user_id, "integer");
    echo '  <script> 
                console.log('.$user_id.')
            </script>';

    $conn = new mysqli('localhost', 'root', '', 'SE_project');
    if($conn->connect_error)
    {
        echo '  <script> 
                    location.replace("http://127.0.0.1:5500/viewprofile.html?success=0");
                </script>';
    }
    else
    {
        $sel = $conn->prepare("SELECT * from user where user_id = ?");
        $sel->bind_param("i", $user_id);
        $sel->execute();

        $res = $sel->get_result();
        $data = $res->fetch_assoc();

        $first_name = $data['first_name'];
        $last_name = $data['last_name'];
        $phone_number = $data['phone_number'];
        $dob = $data['dob'];
        $address = $data['address'];
        $passw = $data['passw'];
        $gender = $data['gender'];
        $cnic = $data['cnic'];
        $email = $data['email'];

        echo '  <script> 
                    location.replace("http://127.0.0.1:5500/viewprofile.html?success=1&first_name='.$first_name.'&last_name='.$last_name.'&phone_number='.$phone_number.
                    '&dob='.$dob.'&address='.$address.'&passw='.$passw.'&gender='.$gender.'&cnic='.$cnic.'&email='.$email.'");
                </script>';
    }
?>