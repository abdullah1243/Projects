#include<iostream>
#include<fstream>
#include<string>
#include<crypt.h>
#include<cstring>
#include<string.h>
#include "mpi.h"

using namespace std;

//main array that holds all variables
char arr[]={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
int length_of_arr=strlen(arr);
// This is the Parsing function. It accessed the /etc/shadow file and finds the user name.
// then it extracts the salt and hash from that line and puts them in variables 1)salt 2)hash by reference 
void Parse(string &salt,string &hash,string name){

fstream infile;
infile.open("pass.txt",ios::in);

//string used to read lines from shadow file
string parsed_line;

while(!infile.eof())
{
    infile>>parsed_line; 
    int i = 0; // i is iterator for line
    string user_name = "";
    while(parsed_line[i] != ':') //  loop for putting user name until semicolon(:) into the user_name string
    {
        user_name += parsed_line[i];
        i++;
    }

    if(user_name == name){ //comparing the name with the user_name that was just read
        i++;
        int dollar_count = 0; //If name matches then we need salt. For that we use dollar count to run a loop until 3 dollar signs($) are passed
{        while(dollar_count != 3){
            salt += parsed_line[i]; //adding the salt letter by letter to variable
            if(parsed_line[i] == '$'){
                dollar_count += 1;
            }
            i +=1;     
        }
        //now we have salt in the salt variable and we need the hash. As salt is part of hash and our i does not reset so we read the other part of hash
        //which is constant and has lenght 86
        int hash_part_counter = 0;
        hash += salt; // concatinating the salt part in hash before reading the left part of hash
        while (hash_part_counter != 86) //loop for getting the other part of hash in the hash variable
        {
            hash += parsed_line[i];
            i += 1;
            hash_part_counter += 1;
        }   
        return;     
    }
}	
}
}
//This is the crypt function it basically just recieves the string (s) that we are trying for potential password, the salt and hash.
// and passes the s and salt to crypt function so it returns the generated hash which we can compare. 
void crypt_function(string s,string salt,string hash){
    
    char *encrypted=crypt(s.c_str(),salt.c_str()); // calling the crypt function
    int len=hash.length(); //getting len of the hash to use in strncmp 
    if(strncmp(encrypted,hash.c_str(),len)==0){ //calling the strncmp function 
        cout<<"Password is successfully cracked!!"<<endl;
        cout<<"Password: "<<s<<endl;
        MPI_Abort(MPI_COMM_WORLD,-1); // MPI Abort call
    }
}
// This is the function which generates all the combinations and send them to the crypt function above to compare and check if that is the password
// This function receives the array of letters,hash,salt,str in which we will concatinate password combinations,len which is 26 for all smallcase letters and letter to search which the current letter
// for which we want to generate combination. 
void Generate_All_Combinations(char* arr, int iterator, string str, int len,string salt,string hash, char letter_to_search)
{
    if (iterator == 0) //base case
    {
        crypt_function(str,salt,hash); // calling crypt function
        return;
    }
 
    for (int j = 0; j < len; j++) { // loop for iterating through the main letter array that we have at the top named as arr
        if(str.length() > 0){ // check to see if the str is empty
            if(str[0] == letter_to_search){ // if str is not empty only allow combinations if letter_to_search is present on the first index 
                string generated_password = str + arr[j]; // combinations starting with the letter_to_search e.g. ka ,kb etc
                Generate_All_Combinations(arr, iterator - 1, generated_password,len,salt,hash,letter_to_search); // using recursion and calling the function itself with iterator-1 which means lenght of password
            }
        }
        else{// else case if str's lenght is 0 which means allow letters a-z
            string generated_password = str + arr[j];
            Generate_All_Combinations(arr, iterator - 1, generated_password,len,salt,hash,letter_to_search); 
        }
    }
    return;
}
int main(int argc,char*argv[]){    
    
    int len = 8; // max lenght for password
    char message[20], processorName[10]; 
    int  i, rank, size, nameLen;
    int root = 0; //root process for mpi

    MPI_Init(&argc, &argv);
    MPI_Comm_size(MPI_COMM_WORLD, &size); //total number of processes
    MPI_Comm_rank(MPI_COMM_WORLD, &rank); //rank of each process

    /*LOAD BALANCING VARIABLES*/
    int division = length_of_arr/size;  //division of array according to number of processes
    int slave_division_size=division*size; //slave division size
    int master_division_size=length_of_arr-slave_division_size; //number of characters given to master process
    
    /*Dynamic memory allocation for storing all letters for each process */
    char **char_to_search=new char * [size];
    for(int i=0;i<size;i++){
        char_to_search[i] = new char [division+master_division_size];
    }
    for(int i=0;i<size;i++){
        for(int j=0;j<division+master_division_size;j++){
            char_to_search[i][j] = '\0';
        }
    }
    /*Using the division and master division variable to load balance and divide the main array and put them in this 2d array based on rank */
    if(master_division_size>0)
    {
        int start_index = 0;

        for(int i=0;i<size;i++){
            if(i == 0){
                for(;start_index<master_division_size;start_index++){
                    char_to_search[i][start_index] = arr[start_index];
                }
            }
            else{
                for(int j=start_index;start_index<j+division;start_index++){
                    char_to_search[i][start_index-j] = arr[start_index];
            }
            }
        }
        
    }
    else if(master_division_size == 0)
    {
        int start_index = 0;
        for(int i=1;i<size;i++){
            for(int j=start_index;start_index<j+division;start_index++){
                char_to_search[i][start_index-j] = arr[start_index];
            }
        }
    }
    if(rank==root)
    {
        cout<<"Entered Root"<<endl;
        string user_name="";
        string salt="";
        string hash="";

	    cout<<"Enter the User Name: ";
        cin>>user_name;
        Parse(salt,hash,user_name);

        cout<<"Salt In Process:- "<<i<<" Is "<<salt<<endl;
        cout<<"Hash In Process:- "<<i<<" Is "<<hash<<endl;

        for(int i=1;i<size;i++){
            /*mpi send call to send all processes the salt and hash*/
            MPI_Send(salt.c_str(),salt.length(),MPI_CHAR,i,666+i,MPI_COMM_WORLD); 
            MPI_Send(hash.c_str(),hash.length(),MPI_CHAR,i,777+i,MPI_COMM_WORLD);
        }
        
        int length = strlen(char_to_search[rank]); 
        /*Generation of combination for master*/
        for(int j = 1;j<len;j++){
            for(int i=0;i<length;i++){
                Generate_All_Combinations(arr,j,"",length_of_arr,salt,hash,char_to_search[rank][i]);
            }
        }   
    }

    for (int i=1;i<size;i++)
    {
        if(rank==i)
        {
            char salt_t[1000];
            char hash_t[1000];
            /*to remove garbage values from both arrays*/
            memset (salt_t,'\0',1000); 
            memset (hash_t,'\0',1000);
            /*mpi receive calls to get the salt and hash and store them in the salt_t and hash_t arrays*/
            MPI_Recv(salt_t,1000,MPI_CHAR,0,666+i,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
            MPI_Recv(hash_t,1000,MPI_CHAR,0,777+i,MPI_COMM_WORLD,MPI_STATUS_IGNORE);
            
            string salt=salt_t;
            string hash=hash_t;
            /*Generation of combination for each slave*/            
            int length = strlen(char_to_search[rank]); 
            for(int j = 1;j<len;j++){
                for(int i=0;i<length;i++){
                    Generate_All_Combinations(arr,j,"",length_of_arr,salt,hash,char_to_search[rank][i]);
                }
            }
        }
    }
    MPI_Finalize();
    return 0;
}