import numpy as np
import copy
import math
import os

WHITE_ROOK = "\u265C"
WHITE_KNIGHT = "\u265E"
WHITE_BISHOP = "\u265D"
WHITE_QUEEN = "\u265B"
WHITE_KING = "\u265A"
WHITE_PAWN = "\u265F"
BLACK_ROOK = "\u2656"
BLACK_KNIGHT = "\u2658"
BLACK_BISHOP = "\u2657"
BLACK_QUEEN = "\u2655"
BLACK_KING = "\u2654"
BLACK_PAWN = "\u2659"
BLANK_SPACE = "\u25AD"

QUEEN_POINTS = 9
ROOK_POINTS = 5
BISHOP_POINTS = 3
KNIGHT_POINTS = 3
PAWN_POINTS = 1
KING_POINTS = 900
BLANK_SPACE_POINTS = 0
TOTAL_PIECE_SCORE = QUEEN_POINTS + ROOK_POINTS + BISHOP_POINTS + KNIGHT_POINTS + PAWN_POINTS + KING_POINTS


def Print_Matrix(chess_matrix, x, y):
    for i in range(0, x):
        for j in range(0, y):
            print(chess_matrix[i][j], end=" ")
        print()


class Pieces:
    King = np.zeros(shape=2, dtype=int)
    Queen = np.zeros(shape=2, dtype=int)
    Knight = np.zeros(shape=(2, 2), dtype=int)
    Rook = np.zeros(shape=(2, 2), dtype=int)
    Bishop = np.zeros(shape=(2, 2), dtype=int)
    Pawn = np.zeros(shape=(8, 2), dtype=int)
    Pawn_flag = [True for i in range(8)]

    def __init__(self, player, color):
        self.King = np.zeros(shape=2, dtype=int)
        self.Queen = np.zeros(shape=2, dtype=int)
        self.Knight = np.zeros(shape=(2, 2), dtype=int)
        self.Rook = np.zeros(shape=(2, 2), dtype=int)
        self.Bishop = np.zeros(shape=(2, 2), dtype=int)
        self.Pawn = np.zeros(shape=(8, 2), dtype=int)
        self.Pawn_flag = [True for i in range(8)]

        if player == 1:  # if player is white and AI is black
            if color == 1:  # storing for white
                self.Rook[0][0] = 7
                self.Rook[0][1] = 0
                self.Knight[0][0] = 7
                self.Knight[0][1] = 1
                self.Bishop[0][0] = 7
                self.Bishop[0][1] = 2
                self.Queen[0] = 7
                self.Queen[1] = 3
                self.King[0] = 7
                self.King[1] = 4
                self.Bishop[1][0] = 7
                self.Bishop[1][1] = 5
                self.Knight[1][0] = 7
                self.Knight[1][1] = 6
                self.Rook[1][0] = 7
                self.Rook[1][1] = 7
                for i in range(8):
                    self.Pawn[i][0] = 6
                    self.Pawn[i][1] = i

            else:  # storing for black
                self.Rook[0][0] = 0
                self.Rook[0][1] = 0
                self.Knight[0][0] = 0
                self.Knight[0][1] = 1
                self.Bishop[0][0] = 0
                self.Bishop[0][1] = 2
                self.Queen[0] = 0
                self.Queen[1] = 3
                self.King[0] = 0
                self.King[1] = 4
                self.Bishop[1][0] = 0
                self.Bishop[1][1] = 5
                self.Knight[1][0] = 0
                self.Knight[1][1] = 6
                self.Rook[1][0] = 0
                self.Rook[1][1] = 7
                for i in range(8):
                    self.Pawn[i][0] = 1
                    self.Pawn[i][1] = i

        else:  # if player is black and AI is white
            if color == 1:  # storing for white
                self.Rook[0][0] = 0
                self.Rook[0][1] = 0
                self.Knight[0][0] = 0
                self.Knight[0][1] = 1
                self.Bishop[0][0] = 0
                self.Bishop[0][1] = 2
                self.King[0] = 0
                self.King[1] = 3
                self.Queen[0] = 0
                self.Queen[1] = 4
                self.Bishop[1][0] = 0
                self.Bishop[1][1] = 5
                self.Knight[1][0] = 0
                self.Knight[1][1] = 6
                self.Rook[1][0] = 0
                self.Rook[1][1] = 7
                for i in range(8):
                    self.Pawn[i][0] = 1
                    self.Pawn[i][1] = i

            else:  # storing for black
                self.Rook[0][0] = 7
                self.Rook[0][1] = 0
                self.Knight[0][0] = 7
                self.Knight[0][1] = 1
                self.Bishop[0][0] = 7
                self.Bishop[0][1] = 2
                self.King[0] = 7
                self.King[1] = 3
                self.Queen[0] = 7
                self.Queen[1] = 4
                self.Bishop[1][0] = 7
                self.Bishop[1][1] = 5
                self.Knight[1][0] = 7
                self.Knight[1][1] = 6
                self.Rook[1][0] = 7
                self.Rook[1][1] = 7
                for i in range(8):
                    self.Pawn[i][0] = 6
                    self.Pawn[i][1] = i


def Calculate_Points_BLACK(board, x, y, piece):
    points = 0
    if board[x][y] == WHITE_QUEEN:
        points += QUEEN_POINTS

        piece.Queen[0] = -10
        piece.Queen[1] = -10
    elif board[x][y] == WHITE_KING:
        points += KING_POINTS

        piece.King[0] = -10
        piece.King[1] = -10
    elif board[x][y] == WHITE_PAWN:
        points += PAWN_POINTS

        for i in range(8):
            if piece.Pawn[i][0] == x and piece.Pawn[i][1] == y:
                piece.Pawn[i][0] = -10
                piece.Pawn[i][1] = -10
                break
    elif board[x][y] == WHITE_ROOK:
        points += ROOK_POINTS

        for i in range(2):
            if piece.Rook[i][0] == x and piece.Rook[i][1] == y:
                piece.Rook[i][0] = -10
                piece.Rook[i][1] = -10
                break
    elif board[x][y] == WHITE_KNIGHT:
        points += KNIGHT_POINTS

        for i in range(2):
            if piece.Knight[i][0] == x and piece.Knight[i][1] == y:
                piece.Knight[i][0] = -10
                piece.Knight[i][1] = -10
                break
    elif board[x][y] == WHITE_BISHOP:
        points += BISHOP_POINTS

        for i in range(2):
            if piece.Bishop[i][0] == x and piece.Bishop[i][1] == y:
                piece.Bishop[i][0] = -10
                piece.Bishop[i][1] = -10
                break
    elif board[x][y] == BLANK_SPACE:
        points += BLANK_SPACE_POINTS
    else:
        return -1
    return points


def Calculate_Points_WHITE(board, x, y, piece):
    points = 0
    if board[x][y] == BLACK_QUEEN:
        points += QUEEN_POINTS

        piece.Queen[0] = -10
        piece.Queen[1] = -10
    elif board[x][y] == BLACK_KING:
        points += KING_POINTS

        piece.King[0] = -10
        piece.King[1] = -10
    elif board[x][y] == BLACK_PAWN:
        points += PAWN_POINTS

        for i in range(8):
            if piece.Pawn[i][0] == x and piece.Pawn[i][1] == y:
                piece.Pawn[i][0] = -10
                piece.Pawn[i][1] = -10
                break
    elif board[x][y] == BLACK_ROOK:
        points += ROOK_POINTS

        for i in range(2):
            if piece.Rook[i][0] == x and piece.Rook[i][1] == y:
                piece.Rook[i][0] = -10
                piece.Rook[i][1] = -10
                break
    elif board[x][y] == BLACK_KNIGHT:
        points += KNIGHT_POINTS

        for i in range(2):
            if piece.Knight[i][0] == x and piece.Knight[i][1] == y:
                piece.Knight[i][0] = -10
                piece.Knight[i][1] = -10
                break
    elif board[x][y] == BLACK_BISHOP:
        points += BISHOP_POINTS

        for i in range(2):
            if piece.Bishop[i][0] == x and piece.Bishop[i][1] == y:
                piece.Bishop[i][0] = -10
                piece.Bishop[i][1] = -10
                break
    elif board[x][y] == BLANK_SPACE:
        points += BLANK_SPACE_POINTS
    else:
        return -1
    return points


def check_attack(board, x, y, player, white_piece, black_piece):
    if player == 1:
        # Queen attacks
        flag1 = True

        path_len = abs(black_piece.Queen[0] - x)

        if black_piece.Queen[0] == x:  # checking horizontally
            if black_piece.Queen[1] < y:
                for i in range(black_piece.Queen[1], y):
                    if board[x][i] == WHITE_ROOK or board[x][i] == WHITE_KNIGHT or board[x][i] == WHITE_BISHOP or \
                            board[x][i] == WHITE_PAWN or board[x][i] == BLACK_ROOK or board[x][i] == BLACK_KNIGHT or \
                            board[x][i] == BLACK_BISHOP or board[x][i] == BLACK_PAWN or board[x][i] == WHITE_QUEEN or \
                            board[x][i] == BLACK_KING or board[x][i] == WHITE_KING:
                        flag1 = False
                        break

            else:
                for i in range(y + 1, black_piece.Queen[1] + 1):
                    if board[x][i] == WHITE_ROOK or board[x][i] == WHITE_KNIGHT or board[x][i] == WHITE_BISHOP or \
                            board[x][i] == WHITE_PAWN or board[x][i] == BLACK_ROOK or board[x][i] == BLACK_KNIGHT or \
                            board[x][i] == BLACK_BISHOP or board[x][i] == BLACK_PAWN or board[x][i] == WHITE_QUEEN or \
                            board[x][i] == BLACK_KING or board[x][i] == WHITE_KING:
                        flag1 = False
                        break

        elif black_piece.Queen[1] == y:  # checking vertically
            if black_piece.Queen[0] < x:
                for i in range(black_piece.Queen[0], x):
                    if board[i][y] == WHITE_ROOK or board[i][y] == WHITE_KNIGHT or board[i][y] == WHITE_BISHOP or \
                            board[i][y] == WHITE_PAWN or board[i][y] == BLACK_ROOK or board[i][y] == BLACK_KNIGHT or \
                            board[i][y] == BLACK_BISHOP or board[i][y] == BLACK_PAWN or board[i][y] == WHITE_QUEEN or \
                            board[i][y] == BLACK_KING or board[i][y] == WHITE_KING:
                        flag1 = False
                        break

            else:
                for i in range(x + 1, black_piece.Queen[0] + 1):
                    if board[i][y] == WHITE_ROOK or board[i][y] == WHITE_KNIGHT or board[i][y] == WHITE_BISHOP or \
                            board[i][y] == WHITE_PAWN or board[i][y] == BLACK_ROOK or board[i][y] == BLACK_KNIGHT or \
                            board[i][y] == BLACK_BISHOP or board[i][y] == BLACK_PAWN or board[i][y] == WHITE_QUEEN or \
                            board[i][y] == BLACK_KING or board[i][y] == WHITE_KING:
                        flag1 = False
                        break

            # checking diagonally
        elif path_len == abs(black_piece.Queen[1] - y):
            if black_piece.Queen[0] < x and black_piece.Queen[1] < y:
                tempx = copy.deepcopy(black_piece.Queen[0])
                tempy = copy.deepcopy(black_piece.Queen[1])
                for i in range(path_len - 1):
                    tempx += 1
                    tempy += 1
                    if board[tempx][tempy] == WHITE_ROOK or board[tempx][tempy] == WHITE_KNIGHT or \
                            board[tempx][tempy] == WHITE_BISHOP or board[tempx][tempy] == WHITE_PAWN or \
                            board[tempx][tempy] == BLACK_ROOK or board[tempx][tempy] == BLACK_KNIGHT or \
                            board[tempx][tempy] == BLACK_BISHOP or board[tempx][tempy] == BLACK_PAWN or \
                            board[tempx][tempy] == WHITE_QUEEN or board[tempx][tempy] == BLACK_KING or \
                            board[tempx][tempy] == WHITE_KING:
                        flag1 = False
                        break

            elif black_piece.Queen[0] > x and black_piece.Queen[1] < y:
                tempx = copy.deepcopy(black_piece.Queen[0])
                tempy = copy.deepcopy(black_piece.Queen[1])
                for i in range(path_len - 1):
                    tempx -= 1
                    tempy += 1
                    if board[tempx][tempy] == WHITE_ROOK or board[tempx][tempy] == WHITE_KNIGHT or \
                            board[tempx][tempy] == WHITE_BISHOP or board[tempx][tempy] == WHITE_PAWN or \
                            board[tempx][tempy] == BLACK_ROOK or board[tempx][tempy] == BLACK_KNIGHT or \
                            board[tempx][tempy] == BLACK_BISHOP or board[tempx][tempy] == BLACK_PAWN or \
                            board[tempx][tempy] == WHITE_QUEEN or board[tempx][tempy] == BLACK_KING or \
                            board[tempx][tempy] == WHITE_KING:
                        flag1 = False
                    break

            elif black_piece.Queen[0] < x and black_piece.Queen[1] > y:
                tempx = copy.deepcopy(black_piece.Queen[0])
                tempy = copy.deepcopy(black_piece.Queen[1])
                for i in range(path_len - 1):
                    tempx += 1
                    tempy -= 1
                    if board[tempx][tempy] == WHITE_ROOK or board[tempx][tempy] == WHITE_KNIGHT or \
                            board[tempx][tempy] == WHITE_BISHOP or board[tempx][tempy] == WHITE_PAWN or \
                            board[tempx][tempy] == BLACK_ROOK or board[tempx][tempy] == BLACK_KNIGHT or \
                            board[tempx][tempy] == BLACK_BISHOP or board[tempx][tempy] == BLACK_PAWN or \
                            board[tempx][tempy] == WHITE_QUEEN or board[tempx][tempy] == BLACK_KING or \
                            board[tempx][tempy] == WHITE_KING:
                        flag1 = False
                        break

            elif black_piece.Queen[0] > x and black_piece.Queen[1] > y:
                tempx = copy.deepcopy(black_piece.Queen[0])
                tempy = copy.deepcopy(black_piece.Queen[1])
                for i in range(path_len - 1):
                    tempx -= 1
                    tempy -= 1
                    if board[tempx][tempy] == WHITE_ROOK or board[tempx][tempy] == WHITE_KNIGHT or \
                            board[tempx][tempy] == WHITE_BISHOP or board[tempx][tempy] == WHITE_PAWN or \
                            board[tempx][tempy] == BLACK_ROOK or board[tempx][tempy] == BLACK_KNIGHT or \
                            board[tempx][tempy] == BLACK_BISHOP or board[tempx][tempy] == BLACK_PAWN or \
                            board[tempx][tempy] == WHITE_QUEEN or board[tempx][tempy] == BLACK_KING or \
                            board[tempx][tempy] == WHITE_KING:
                        flag1 = False
                        break

        else:
            flag1 = False

        if flag1:
            if board[x][y] == BLACK_QUEEN:
                flag1 = False

        flag2 = [True, True]

        # bishop attacks
        for f in range(2):
            path_len = abs(black_piece.Bishop[f][0] - x)

            if path_len == abs(black_piece.Bishop[f][0] - y):
                if black_piece.Bishop[f][0] < x and black_piece.Bishop[f][1] < y:
                    tempx = copy.deepcopy(x)
                    tempy = copy.deepcopy(y)
                    for i in range(path_len):
                        tempx += 1
                        tempy += 1
                        if board[tempx][tempy] == WHITE_ROOK or board[tempx][tempy] == WHITE_KNIGHT or \
                                board[tempx][tempy] == WHITE_BISHOP or board[tempx][tempy] == WHITE_PAWN or \
                                board[tempx][tempy] == BLACK_ROOK or board[tempx][tempy] == BLACK_KNIGHT or \
                                board[tempx][tempy] == BLACK_QUEEN or board[tempx][tempy] == BLACK_PAWN or \
                                board[tempx][tempy] == WHITE_QUEEN or board[tempx][tempy] == BLACK_KING or \
                                board[tempx][tempy] == WHITE_KING:
                            flag2[f] = False
                            break

                elif black_piece.Bishop[f][0] > x and black_piece.Bishop[f][1] < y:
                    tempx = copy.deepcopy(x)
                    tempy = copy.deepcopy(y)
                    for i in range(path_len - 1):
                        tempx -= 1
                        tempy += 1
                        if board[tempx][tempy] == WHITE_ROOK or board[tempx][tempy] == WHITE_KNIGHT or \
                                board[tempx][tempy] == WHITE_BISHOP or board[tempx][tempy] == WHITE_PAWN or \
                                board[tempx][tempy] == BLACK_ROOK or board[tempx][tempy] == BLACK_KNIGHT or \
                                board[tempx][tempy] == BLACK_QUEEN or board[tempx][tempy] == BLACK_PAWN or \
                                board[tempx][tempy] == WHITE_QUEEN or board[tempx][tempy] == BLACK_KING or \
                                board[tempx][tempy] == WHITE_KING:
                            flag2[f] = False
                            break

                elif black_piece.Bishop[f][0] < x and black_piece.Bishop[f][1] > y:
                    tempx = copy.deepcopy(x)
                    tempy = copy.deepcopy(y)
                    for i in range(path_len - 1):
                        tempx += 1
                        tempy -= 1
                        if board[tempx][tempy] == WHITE_ROOK or board[tempx][tempy] == WHITE_KNIGHT or \
                                board[tempx][tempy] == WHITE_BISHOP or board[tempx][tempy] == WHITE_PAWN or \
                                board[tempx][tempy] == BLACK_ROOK or board[tempx][tempy] == BLACK_KNIGHT or \
                                board[tempx][tempy] == BLACK_QUEEN or board[tempx][tempy] == BLACK_PAWN or \
                                board[tempx][tempy] == WHITE_QUEEN or board[tempx][tempy] == BLACK_KING or \
                                board[tempx][tempy] == WHITE_KING:
                            flag2[f] = False
                            break

                elif black_piece.Bishop[f][0] > x and black_piece.Bishop[f][1] > y:
                    tempx = copy.deepcopy(x)
                    tempy = copy.deepcopy(y)
                    for i in range(path_len - 1):
                        tempx -= 1
                        tempy -= 1
                        if board[tempx][tempy] == WHITE_ROOK or board[tempx][tempy] == WHITE_KNIGHT or \
                                board[tempx][tempy] == WHITE_BISHOP or board[tempx][tempy] == WHITE_PAWN or \
                                board[tempx][tempy] == BLACK_ROOK or board[tempx][tempy] == BLACK_KNIGHT or \
                                board[tempx][tempy] == BLACK_QUEEN or board[tempx][tempy] == BLACK_PAWN or \
                                board[tempx][tempy] == WHITE_QUEEN or board[tempx][tempy] == BLACK_KING or \
                                board[tempx][tempy] == WHITE_KING:
                            flag2[f] = False
                            break

            else:
                flag2[f] = False

            if flag2[f]:
                if black_piece.Bishop[f][0] == x and black_piece.Bishop[f][1] == y and board[x][y] == BLACK_ROOK:
                    flag2[f] = False

        flag3 = [True, True]

        # rook attacks
        for f in range(2):
            if black_piece.Rook[f][0] == x:  # checking horizontally
                if black_piece.Rook[f][1] < y:
                    for i in range(black_piece.Rook[f][1], y):
                        if board[x][i] == WHITE_ROOK or board[x][i] == WHITE_KNIGHT or \
                                board[x][i] == WHITE_BISHOP or board[x][i] == WHITE_PAWN or \
                                board[x][i] == BLACK_ROOK or board[x][i] == BLACK_KNIGHT or \
                                board[x][i] == BLACK_BISHOP or board[x][i] == BLACK_PAWN or \
                                board[x][i] == WHITE_QUEEN or board[x][i] == BLACK_KING or \
                                board[x][i] == BLACK_QUEEN or board[x][i] == WHITE_KING:
                            flag3[f] = False
                            break

                else:
                    for i in range(y + 1, black_piece.Rook[f][1] + 1):
                        if board[x][i] == WHITE_ROOK or board[x][i] == WHITE_KNIGHT or \
                                board[x][i] == WHITE_BISHOP or board[x][i] == WHITE_PAWN or \
                                board[x][i] == BLACK_ROOK or board[x][i] == BLACK_KNIGHT or \
                                board[x][i] == BLACK_BISHOP or board[x][i] == BLACK_PAWN or \
                                board[x][i] == WHITE_QUEEN or board[x][i] == BLACK_KING or \
                                board[x][i] == BLACK_QUEEN or board[x][i] == WHITE_KING:
                            flag3[f] = False
                            break

            elif black_piece.Rook[f][1] == y:  # checking vertically
                if black_piece.Rook[f][0] < x:
                    for i in range(black_piece.Rook[f][0], x):
                        if board[i][y] == WHITE_ROOK or board[i][y] == WHITE_KNIGHT or \
                                board[i][y] == WHITE_BISHOP or board[i][y] == WHITE_PAWN or \
                                board[i][y] == BLACK_ROOK or board[i][y] == BLACK_KNIGHT or \
                                board[i][y] == BLACK_BISHOP or board[i][y] == BLACK_PAWN or \
                                board[i][y] == WHITE_QUEEN or board[i][y] == BLACK_KING or \
                                board[i][y] == BLACK_QUEEN or board[i][y] == WHITE_KING:
                            flag3[f] = False
                            break

                else:
                    for i in range(x + 1, black_piece.Rook[f][0] + 1):
                        if board[i][y] == WHITE_ROOK or board[i][y] == WHITE_KNIGHT or \
                                board[i][y] == WHITE_BISHOP or board[i][y] == WHITE_PAWN or \
                                board[i][y] == BLACK_ROOK or board[i][y] == BLACK_KNIGHT or \
                                board[i][y] == BLACK_BISHOP or board[i][y] == BLACK_PAWN or \
                                board[i][y] == WHITE_QUEEN or board[i][y] == BLACK_KING or \
                                board[i][y] == BLACK_QUEEN or board[i][y] == WHITE_KING:
                            flag3[f] = False
                            break

            else:
                flag3[f] = False

            if flag3[f]:
                if black_piece.Rook[f][0] == x and black_piece.Rook[f][1] == y and board[x][y] == BLACK_ROOK:
                    flag3[f] = False

        flag4 = [False, False]

        # knight attacks
        for f in range(2):
            if ((black_piece.Knight[f][0] + 2 == x and black_piece.Knight[f][1] + 1 == y) or
                    (black_piece.Knight[f][0] + 1 == x and black_piece.Knight[f][1] + 2 == y) or
                    (black_piece.Knight[f][0] - 2 == x and black_piece.Knight[f][1] + 1 == y) or
                    (black_piece.Knight[f][0] - 1 == x and black_piece.Knight[f][1] + 2 == y) or
                    (black_piece.Knight[f][0] + 2 == x and black_piece.Knight[f][1] - 1 == y) or
                    (black_piece.Knight[f][0] + 1 == x and black_piece.Knight[f][1] - 2 == y) or
                    (black_piece.Knight[f][0] - 2 == x and black_piece.Knight[f][1] - 1 == y) or
                    (black_piece.Knight[f][0] - 1 == x and black_piece.Knight[f][1] - 2 == y)):
                flag4[f] = True

            if flag4[f]:
                if black_piece.Knight[f][0] == x and black_piece.Knight[f][1] == y and board[x][y] == BLACK_KNIGHT:
                    flag4[f] = False

        flag5 = [False for i in range(8)]

        for f in range(8):
            if black_piece.Pawn[f][1] != y:
                if (y == black_piece.Pawn[f][1] - 1 and x == black_piece.Pawn[f][0] - 1) or \
                        (y == black_piece.Pawn[f][1] + 1 and x == black_piece.Pawn[f][0] - 1):
                    flag5[f] = True

            if flag5[f]:
                if black_piece.Pawn[f][0] == x and black_piece.Pawn[f][1] == y and board[x][y] == BLACK_PAWN:
                    flag5[f] = False

        flag6 = False

        # King attacks
        if ((black_piece.King[0] + 1 == x and black_piece.King[1] + 1 == y) or
                (black_piece.King[0] - 1 == x and black_piece.King[1] + 1 == y) or
                (black_piece.King[0] + 1 == x and black_piece.King[1] - 1 == y) or
                (black_piece.King[0] - 1 == x and black_piece.King[1] - 1 == y) or
                (black_piece.King[0] + 1 == x and black_piece.King[1] == y) or
                (black_piece.King[0] - 1 == x and black_piece.King[1] == y) or
                (black_piece.King[0] == x and black_piece.King[1] - 1 == y) or
                (black_piece.King[0] == x and black_piece.King[1] - 1 == y)):
            flag6 = True

        if not flag1 and True not in flag2 and True not in flag3 and True not in flag4 and True not in flag5 \
                and not flag6:
            return False

        return True

    else:
        # Queen attacks
        flag1 = True

        path_len = abs(white_piece.Queen[0] - x)

        if white_piece.Queen[0] == x:  # checking horizontally
            if white_piece.Queen[1] < y:
                for i in range(white_piece.Queen[1], y):
                    if board[x][i] == WHITE_ROOK or board[x][i] == WHITE_KNIGHT or board[x][i] == WHITE_BISHOP or \
                            board[x][i] == WHITE_PAWN or board[x][i] == BLACK_ROOK or board[x][i] == BLACK_KNIGHT or \
                            board[x][i] == BLACK_BISHOP or board[x][i] == BLACK_PAWN or board[x][i] == WHITE_QUEEN or \
                            board[x][i] == BLACK_KING or board[x][i] == WHITE_KING:
                        flag1 = False
                        break

            else:
                for i in range(y + 1, white_piece.Queen[1] + 1):
                    if board[x][i] == WHITE_ROOK or board[x][i] == WHITE_KNIGHT or board[x][i] == WHITE_BISHOP or \
                            board[x][i] == WHITE_PAWN or board[x][i] == BLACK_ROOK or board[x][i] == BLACK_KNIGHT or \
                            board[x][i] == BLACK_BISHOP or board[x][i] == BLACK_PAWN or board[x][i] == WHITE_QUEEN or \
                            board[x][i] == BLACK_KING or board[x][i] == WHITE_KING:
                        flag1 = False
                        break

        elif white_piece.Queen[1] == y:  # checking vertically
            if white_piece.Queen[0] < x:
                for i in range(white_piece.Queen[0], x):
                    if board[i][y] == WHITE_ROOK or board[i][y] == WHITE_KNIGHT or board[i][y] == WHITE_BISHOP or \
                            board[i][y] == WHITE_PAWN or board[i][y] == BLACK_ROOK or board[i][y] == BLACK_KNIGHT or \
                            board[i][y] == BLACK_BISHOP or board[i][y] == BLACK_PAWN or board[i][y] == WHITE_QUEEN or \
                            board[i][y] == BLACK_KING or board[i][y] == WHITE_KING:
                        flag1 = False
                        break

            else:
                for i in range(x + 1, white_piece.Queen[0] + 1):
                    if board[i][y] == WHITE_ROOK or board[i][y] == WHITE_KNIGHT or board[i][y] == WHITE_BISHOP or \
                            board[i][y] == WHITE_PAWN or board[i][y] == BLACK_ROOK or board[i][y] == BLACK_KNIGHT or \
                            board[i][y] == BLACK_BISHOP or board[i][y] == BLACK_PAWN or board[i][y] == WHITE_QUEEN or \
                            board[i][y] == BLACK_KING or board[i][y] == WHITE_KING:
                        flag1 = False
                        break

            # checking diagonally
        elif path_len == abs(white_piece.Queen[1] - y):
            if white_piece.Queen[0] < x and white_piece.Queen[1] < y:
                tempx = copy.deepcopy(white_piece.Queen[0])
                tempy = copy.deepcopy(white_piece.Queen[1])
                for i in range(path_len - 1):
                    tempx += 1
                    tempy += 1
                    if board[tempx][tempy] == WHITE_ROOK or board[tempx][tempy] == WHITE_KNIGHT or \
                            board[tempx][tempy] == WHITE_BISHOP or board[tempx][tempy] == WHITE_PAWN or \
                            board[tempx][tempy] == BLACK_ROOK or board[tempx][tempy] == BLACK_KNIGHT or \
                            board[tempx][tempy] == BLACK_BISHOP or board[tempx][tempy] == BLACK_PAWN or \
                            board[tempx][tempy] == WHITE_QUEEN or board[tempx][tempy] == BLACK_KING or \
                            board[tempx][tempy] == WHITE_KING:
                        flag1 = False
                        break

            elif white_piece.Queen[0] > x and white_piece.Queen[1] < y:
                tempx = copy.deepcopy(white_piece.Queen[0])
                tempy = copy.deepcopy(white_piece.Queen[1])
                for i in range(path_len - 1):
                    tempx -= 1
                    tempy += 1
                    if board[tempx][tempy] == WHITE_ROOK or board[tempx][tempy] == WHITE_KNIGHT or \
                            board[tempx][tempy] == WHITE_BISHOP or board[tempx][tempy] == WHITE_PAWN or \
                            board[tempx][tempy] == BLACK_ROOK or board[tempx][tempy] == BLACK_KNIGHT or \
                            board[tempx][tempy] == BLACK_BISHOP or board[tempx][tempy] == BLACK_PAWN or \
                            board[tempx][tempy] == WHITE_QUEEN or board[tempx][tempy] == BLACK_KING or \
                            board[tempx][tempy] == WHITE_KING:
                        flag1 = False
                        break

            elif white_piece.Queen[0] < x and white_piece.Queen[1] > y:
                tempx = copy.deepcopy(white_piece.Queen[0])
                tempy = copy.deepcopy(white_piece.Queen[1])
                for i in range(path_len - 1):
                    tempx += 1
                    tempy -= 1
                    if board[tempx][tempy] == WHITE_ROOK or board[tempx][tempy] == WHITE_KNIGHT or \
                            board[tempx][tempy] == WHITE_BISHOP or board[tempx][tempy] == WHITE_PAWN or \
                            board[tempx][tempy] == BLACK_ROOK or board[tempx][tempy] == BLACK_KNIGHT or \
                            board[tempx][tempy] == BLACK_BISHOP or board[tempx][tempy] == BLACK_PAWN or \
                            board[tempx][tempy] == WHITE_QUEEN or board[tempx][tempy] == BLACK_KING or \
                            board[tempx][tempy] == WHITE_KING:
                        flag1 = False
                        break

            elif white_piece.Queen[0] > x and white_piece.Queen[1] > y:
                tempx = copy.deepcopy(white_piece.Queen[0])
                tempy = copy.deepcopy(white_piece.Queen[1])
                for i in range(path_len - 1):
                    tempx -= 1
                    tempy -= 1
                    if board[tempx][tempy] == WHITE_ROOK or board[tempx][tempy] == WHITE_KNIGHT or \
                            board[tempx][tempy] == WHITE_BISHOP or board[tempx][tempy] == WHITE_PAWN or \
                            board[tempx][tempy] == BLACK_ROOK or board[tempx][tempy] == BLACK_KNIGHT or \
                            board[tempx][tempy] == BLACK_BISHOP or board[tempx][tempy] == BLACK_PAWN or \
                            board[tempx][tempy] == WHITE_QUEEN or board[tempx][tempy] == BLACK_KING or \
                            board[tempx][tempy] == WHITE_KING:
                        flag1 = False
                        break

        else:
            flag1 = False

        if flag1:
            if board[x][y] == WHITE_QUEEN:
                flag1 = False

        flag2 = [True, True]

        # bishop attacks
        for f in range(2):
            path_len = abs(white_piece.Bishop[f][0] - x)

            if path_len == abs(white_piece.Bishop[f][0] - y):
                if white_piece.Bishop[f][0] < x and white_piece.Bishop[f][1] < y:
                    tempx = copy.deepcopy(x)
                    tempy = copy.deepcopy(y)
                    for i in range(path_len - 1):
                        tempx += 1
                        tempy += 1
                        if board[tempx][tempy] == WHITE_ROOK or board[tempx][tempy] == WHITE_KNIGHT or \
                                board[tempx][tempy] == WHITE_BISHOP or board[tempx][tempy] == WHITE_PAWN or \
                                board[tempx][tempy] == BLACK_ROOK or board[tempx][tempy] == BLACK_KNIGHT or \
                                board[tempx][tempy] == BLACK_QUEEN or board[tempx][tempy] == BLACK_PAWN or \
                                board[tempx][tempy] == WHITE_QUEEN or board[tempx][tempy] == BLACK_KING or \
                                board[tempx][tempy] == WHITE_KING:
                            flag2[f] = False
                            break

                elif white_piece.Bishop[f][0] > x and white_piece.Bishop[f][1] < y:
                    tempx = copy.deepcopy(x)
                    tempy = copy.deepcopy(y)
                    for i in range(path_len - 1):
                        tempx -= 1
                        tempy += 1
                        if board[tempx][tempy] == WHITE_ROOK or board[tempx][tempy] == WHITE_KNIGHT or \
                                board[tempx][tempy] == WHITE_BISHOP or board[tempx][tempy] == WHITE_PAWN or \
                                board[tempx][tempy] == BLACK_ROOK or board[tempx][tempy] == BLACK_KNIGHT or \
                                board[tempx][tempy] == BLACK_QUEEN or board[tempx][tempy] == BLACK_PAWN or \
                                board[tempx][tempy] == WHITE_QUEEN or board[tempx][tempy] == BLACK_KING or \
                                board[tempx][tempy] == WHITE_KING:
                            flag2[f] = False
                            break

                elif white_piece.Bishop[f][0] < x and white_piece.Bishop[f][1] > y:
                    tempx = copy.deepcopy(x)
                    tempy = copy.deepcopy(y)
                    for i in range(path_len - 1):
                        tempx += 1
                        tempy -= 1
                        if board[tempx][tempy] == WHITE_ROOK or board[tempx][tempy] == WHITE_KNIGHT or \
                                board[tempx][tempy] == WHITE_BISHOP or board[tempx][tempy] == WHITE_PAWN or \
                                board[tempx][tempy] == BLACK_ROOK or board[tempx][tempy] == BLACK_KNIGHT or \
                                board[tempx][tempy] == BLACK_QUEEN or board[tempx][tempy] == BLACK_PAWN or \
                                board[tempx][tempy] == WHITE_QUEEN or board[tempx][tempy] == BLACK_KING or \
                                board[tempx][tempy] == WHITE_KING:
                            flag2[f] = False
                            break

                elif white_piece.Bishop[f][0] > x and white_piece.Bishop[f][1] > y:
                    tempx = copy.deepcopy(x)
                    tempy = copy.deepcopy(y)
                    for i in range(path_len - 1):
                        tempx -= 1
                        tempy -= 1
                        if board[tempx][tempy] == WHITE_ROOK or board[tempx][tempy] == WHITE_KNIGHT or \
                                board[tempx][tempy] == WHITE_BISHOP or board[tempx][tempy] == WHITE_PAWN or \
                                board[tempx][tempy] == BLACK_ROOK or board[tempx][tempy] == BLACK_KNIGHT or \
                                board[tempx][tempy] == BLACK_QUEEN or board[tempx][tempy] == BLACK_PAWN or \
                                board[tempx][tempy] == WHITE_QUEEN or board[tempx][tempy] == BLACK_KING or \
                                board[tempx][tempy] == WHITE_KING:
                            flag2[f] = False
                            break

            else:
                flag2[f] = False

            if flag2[f]:
                if white_piece.Bishop[f][0] == x and white_piece.Bishop[f][1] == y and board[x][y] == BLACK_ROOK:
                    flag2[f] = False

        flag3 = [True, True]

        # rook attacks
        for f in range(2):
            if white_piece.Rook[f][0] == x:  # checking horizontally
                if white_piece.Rook[f][1] < y:
                    for i in range(white_piece.Rook[f][1], y):
                        if board[x][i] == WHITE_ROOK or board[x][i] == WHITE_KNIGHT or \
                                board[x][i] == WHITE_BISHOP or board[x][i] == WHITE_PAWN or \
                                board[x][i] == BLACK_ROOK or board[x][i] == BLACK_KNIGHT or \
                                board[x][i] == BLACK_BISHOP or board[x][i] == BLACK_PAWN or \
                                board[x][i] == WHITE_QUEEN or board[x][i] == BLACK_KING or \
                                board[x][i] == BLACK_QUEEN or board[x][i] == WHITE_KING:
                            flag3[f] = False
                            break

                else:
                    for i in range(y + 1, white_piece.Rook[f][1] + 1):
                        if board[x][i] == WHITE_ROOK or board[x][i] == WHITE_KNIGHT or \
                                board[x][i] == WHITE_BISHOP or board[x][i] == WHITE_PAWN or \
                                board[x][i] == BLACK_ROOK or board[x][i] == BLACK_KNIGHT or \
                                board[x][i] == BLACK_BISHOP or board[x][i] == BLACK_PAWN or \
                                board[x][i] == WHITE_QUEEN or board[x][i] == BLACK_KING or \
                                board[x][i] == BLACK_QUEEN or board[x][i] == WHITE_KING:
                            flag3[f] = False
                            break

            elif white_piece.Rook[f][1] == y:  # checking vertically
                if white_piece.Rook[f][0] < x:
                    for i in range(white_piece.Rook[f][0], x):
                        if board[i][y] == WHITE_ROOK or board[i][y] == WHITE_KNIGHT or \
                                board[i][y] == WHITE_BISHOP or board[i][y] == WHITE_PAWN or \
                                board[i][y] == BLACK_ROOK or board[i][y] == BLACK_KNIGHT or \
                                board[i][y] == BLACK_BISHOP or board[i][y] == BLACK_PAWN or \
                                board[i][y] == WHITE_QUEEN or board[i][y] == BLACK_KING or \
                                board[i][y] == BLACK_QUEEN or board[i][y] == WHITE_KING:
                            flag3[f] = False
                            break

                else:
                    for i in range(x + 1, white_piece.Rook[f][0] + 1):
                        if board[i][y] == WHITE_ROOK or board[i][y] == WHITE_KNIGHT or \
                                board[i][y] == WHITE_BISHOP or board[i][y] == WHITE_PAWN or \
                                board[i][y] == BLACK_ROOK or board[i][y] == BLACK_KNIGHT or \
                                board[i][y] == BLACK_BISHOP or board[i][y] == BLACK_PAWN or \
                                board[i][y] == WHITE_QUEEN or board[i][y] == BLACK_KING or \
                                board[i][y] == BLACK_QUEEN or board[i][y] == WHITE_KING:
                            flag3[f] = False
                            break

            else:
                flag3[f] = False

            if flag3[f]:
                if white_piece.Rook[f][0] == x and white_piece.Rook[f][1] == y and board[x][y] == WHITE_ROOK:
                    flag3[f] = False

        flag4 = [False, False]

        # knight attacks
        for f in range(2):
            if ((white_piece.Knight[f][0] + 2 == x and white_piece.Knight[f][1] + 1 == y) or
                    (white_piece.Knight[f][0] + 1 == x and white_piece.Knight[f][1] + 2 == y) or
                    (white_piece.Knight[f][0] - 2 == x and white_piece.Knight[f][1] + 1 == y) or
                    (white_piece.Knight[f][0] - 1 == x and white_piece.Knight[f][1] + 2 == y) or
                    (white_piece.Knight[f][0] + 2 == x and white_piece.Knight[f][1] - 1 == y) or
                    (white_piece.Knight[f][0] + 1 == x and white_piece.Knight[f][1] - 2 == y) or
                    (white_piece.Knight[f][0] - 2 == x and white_piece.Knight[f][1] - 1 == y) or
                    (white_piece.Knight[f][0] - 1 == x and white_piece.Knight[f][1] - 2 == y)):
                flag4[f] = True

            if flag4[f]:
                if white_piece.Knight[f][0] == x and white_piece.Knight[f][1] == y and board[x][y] == WHITE_KNIGHT:
                    flag4[f] = False

        flag5 = [False for i in range(8)]

        for f in range(8):
            if white_piece.Pawn[f][1] != y:
                if (y == white_piece.Pawn[f][1] - 1 and x == white_piece.Pawn[f][0] - 1) or \
                        (y == white_piece.Pawn[f][1] + 1 and x == white_piece.Pawn[f][0] - 1):
                    flag5[f] = True

            if flag5[f]:
                if white_piece.Pawn[f][0] == x and white_piece.Pawn[f][1] == y and board[x][y] == WHITE_PAWN:
                    flag5[f] = False

        flag6 = False

        # King attacks
        if ((white_piece.King[0] + 1 == x and white_piece.King[1] + 1 == y) or
                (white_piece.King[0] - 1 == x and white_piece.King[1] + 1 == y) or
                (white_piece.King[0] + 1 == x and white_piece.King[1] - 1 == y) or
                (white_piece.King[0] - 1 == x and white_piece.King[1] - 1 == y) or
                (white_piece.King[0] + 1 == x and white_piece.King[1] == y) or
                (white_piece.King[0] - 1 == x and white_piece.King[1] == y) or
                (white_piece.King[0] == x and white_piece.King[1] - 1 == y) or
                (white_piece.King[0] == x and white_piece.King[1] - 1 == y)):
            flag6 = True

        if not flag1 and True not in flag2 and True not in flag3 and True not in flag4 and True not in flag5 \
                and not flag6:
            return False

        return True


def evaluate(board, player):
    if player == 0:
        points = 0
        for x in range(0, 8):
            for y in range(0, 8):
                if board[x][y] == WHITE_QUEEN:
                    points = points + QUEEN_POINTS
                elif board[x][y] == WHITE_KING:
                    points = points + KING_POINTS
                elif board[x][y] == WHITE_PAWN:
                    points = points + PAWN_POINTS
                elif board[x][y] == WHITE_ROOK:
                    points = points + ROOK_POINTS
                elif board[x][y] == WHITE_KNIGHT:
                    points = points + KNIGHT_POINTS
                elif board[x][y] == WHITE_BISHOP:
                    points = points + BISHOP_POINTS
        return points


def checking_function(flag, matrix, player, chess_board, value):
    if flag:
        board_value = evaluate(matrix, player)
        chess_board.append(matrix)
        value.append(board_value)
    return chess_board, value


def MOVE_FUNCTION(chess_matrix, i, j, move, player, piece_white, piece_black, chess_board, value):
    flag = False

    if move == 1:
        flag = False
        for k in range(0, 8):
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_Rook_Check(matrix, i, j, k, j)  # Checking Vertical Rows
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)
        flag = False
        for k in range(0, 8):
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_Rook_Check(matrix, i, j, i, k)  # Checking Horizontal Columns
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)
    elif move == 2:
        if i + 1 < 8:
            for k in range(i + 1, 8):
                matrix = copy.deepcopy(chess_matrix)
                flag = Move_Pawn_Check(matrix, i, j, k, j, player, piece_white, piece_black)
                chess_board, value = checking_function(flag, matrix, player, chess_board, value)
        if i - 1 >= 0:
            for k in range(i - 1, 8, -1):
                matrix = copy.deepcopy(chess_matrix)
                flag = Move_Pawn_Check(matrix, i, j, k, j, player, piece_white, piece_black)
                chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        if i + 1 < 8 and j + 1 < 8:
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_Pawn_Check(matrix, i, j, i + 1, j + 1, player, piece_white, piece_black)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        if i - 1 >= 0 and j + 1 < 8:
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_Pawn_Check(matrix, i, j, i - 1, j + 1, player, piece_white, piece_black)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        if i + 1 < 8 and j - 1 >= 0:
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_Pawn_Check(matrix, i, j, i + 1, j - 1, player, piece_white, piece_black)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        if i - 1 >= 0 and j - 1 >= 0:
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_Pawn_Check(matrix, i, j, i - 1, j - 1, player, piece_white, piece_black)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

    elif move == 3:
        for k in range(0, i):  # checking left row
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_King_Check(matrix, i, j, k, j, player, piece_white, piece_black)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        for k in range(i, 8):
            matrix = copy.deepcopy(chess_matrix)  # checking right row
            flag = Move_King_Check(matrix, i, j, k, j, player, piece_white, piece_black)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        for k in range(0, i):
            matrix = copy.deepcopy(chess_matrix)  # checking upper col
            flag = Move_King_Check(matrix, i, j, i, k, player, piece_white, piece_black)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        for k in range(i, 8):
            matrix = copy.deepcopy(chess_matrix)  # checking downward col
            flag = Move_King_Check(matrix, i, j, i, k, player, piece_white, piece_black)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)
        if i + 1 < 8 and j + 1 < 8:
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_King_Check(matrix, i, j, i + 1, j + 1, player, piece_white, piece_black)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        if i - 1 >= 0 and j + 1 < 8:
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_King_Check(matrix, i, j, i - 1, j + 1, player, piece_white, piece_black)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        if i + 1 < 8 and j - 1 >= 0:
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_King_Check(matrix, i, j, i + 1, j - 1, player, piece_white, piece_black)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        if i - 1 >= 0 and j - 1 >= 0:
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_King_Check(matrix, i, j, i - 1, j - 1, player, piece_white, piece_black)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)
    elif move == 4:
        for k in range(0, i):  # checking left row
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_Queen_Check(matrix, i, j, k, j, player, piece_white, piece_black)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        for k in range(i, 8):
            matrix = copy.deepcopy(chess_matrix)  # checking right row
            flag = Move_Queen_Check(matrix, i, j, k, j, player, piece_white, piece_black)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        for k in range(0, i):
            matrix = copy.deepcopy(chess_matrix)  # checking upper col
            flag = Move_Queen_Check(matrix, i, j, i, k, player, piece_white, piece_black)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        for k in range(i, 8):
            matrix = copy.deepcopy(chess_matrix)  # checking downward col
            flag = Move_Queen_Check(matrix, i, j, i, k, player, piece_white, piece_black)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        for row in range(i, 8, +1):
            for col in range(j, 8, +1):
                if row == i + 1 and col == j + 1:
                    matrix = copy.deepcopy(chess_matrix)
                    if row + 1 < 8 and col + 1 < 8:
                        flag = Move_Queen_Check(matrix, i, j, row, col, player, piece_white, piece_black)
                        chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        for row in range(i, 8, +1):
            for col in range(j, 0, -1):
                if row == i + 1 and col == j - 1:
                    matrix = copy.deepcopy(chess_matrix)
                    if row + 1 < 8 and col - 1 >= 0:
                        flag = Move_Queen_Check(matrix, i, j, row, col, player, piece_white, piece_black)
                        chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        for row in range(i, 0, -1):
            for col in range(j, 8, +1):
                if row == i - 1 and col == j + 1:
                    matrix = copy.deepcopy(chess_matrix)
                    if row - 1 >= 0 and col + 1 < 8:
                        flag = Move_Queen_Check(matrix, i, j, row, col, player, piece_white, piece_black)
                        chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        for row in range(i, 0, -1):
            for col in range(j, 0, -1):
                if row == i - 1 and col == j - 1:
                    matrix = copy.deepcopy(chess_matrix)
                    if row - 1 >= 0 and col - 1 >= 0:
                        flag = Move_Queen_Check(matrix, i, j, row, col, player, piece_white, piece_black)
                        chess_board, value = checking_function(flag, matrix, player, chess_board, value)

    elif move == 5:
        for row in range(i, 8, +1):
            for col in range(j, 8, +1):
                if row == i + 1 and col == j + 1:
                    matrix = copy.deepcopy(chess_matrix)
                    if row + 1 < 8 and col + 1 < 8:
                        flag = Move_Bishop_Check(matrix, i, j, row, col, player, piece_white, piece_black)
                        chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        for row in range(i, 8, +1):
            for col in range(j, 0, -1):
                if row == i + 1 and col == j - 1:
                    matrix = copy.deepcopy(chess_matrix)
                    if row + 1 < 8 and col - 1 >= 0:
                        flag = Move_Bishop_Check(matrix, i, j, row, col, player, piece_white, piece_black)
                        chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        for row in range(i, 0, -1):
            for col in range(j, 8, +1):
                if row == i - 1 and col == j + 1:
                    matrix = copy.deepcopy(chess_matrix)
                    if row - 1 >= 0 and col + 1 < 8:
                        flag = Move_Bishop_Check(matrix, i, j, row, col, player, piece_white, piece_black)
                        chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        for row in range(i, 0, -1):
            for col in range(j, 0, -1):
                if row == i - 1 and col == j - 1:
                    matrix = copy.deepcopy(chess_matrix)
                    if row - 1 >= 0 and col - 1 >= 0:
                        flag = Move_Bishop_Check(matrix, i, j, row, col, player, piece_white, piece_black)
                        chess_board, value = checking_function(flag, matrix, player, chess_board, value)

    elif move == 6:
        if i + 2 < 8 and j - 1 >= 0:  # left knight check
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_Knight_Check(matrix, i, j, i + 2, j - 1)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)
        if i + 2 < 8 and j + 1 < 8:
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_Knight_Check(matrix, i, j, i + 2, j + 1)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        if i - 2 >= 0 and j + 1 < 8:
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_Knight_Check(matrix, i, j, i - 2, j + 1)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        if i - 2 >= 0 and j - 1 >= 0:
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_Knight_Check(matrix, i, j, i - 2, j - 1)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        if i + 1 >= 0 and j + 2 >= 0:
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_Knight_Check(matrix, i, j, i + 2, j + 1)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        if i + 1 >= 0 and j - 2 >= 0:
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_Knight_Check(matrix, i, j, i + 1, j - 2)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        if i - 1 >= 0 and j - 2 >= 0:
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_Knight_Check(matrix, i, j, i - 1, j - 2)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

        if i - 1 >= 0 and j + 2 >= 0:
            matrix = copy.deepcopy(chess_matrix)
            flag = Move_Knight_Check(matrix, i, j, i - 1, j + 2)
            chess_board, value = checking_function(flag, matrix, player, chess_board, value)

    return chess_board, value


def minimax(matrix, player, piece_white, piece_black):
    move = 0

    chess_board = []
    value = []
    for i in range(0, 8):
        for j in range(0, 8):
            chess_matrix = copy.deepcopy(matrix)
            if chess_matrix[i][j] == BLACK_ROOK:
                move = 1
            elif chess_matrix[i][j] == BLACK_PAWN:
                move = 2
            elif chess_matrix[i][j] == BLACK_KING:
                move = 3
            elif chess_matrix[i][j] == BLACK_QUEEN:
                move = 4
            elif chess_matrix[i][j] == BLACK_BISHOP:
                move = 5
            elif chess_matrix[i][j] == BLACK_KNIGHT:
                move = 6
            else:
                continue
            chess_board, value = MOVE_FUNCTION(chess_matrix, i, j, move, player, piece_white, piece_black, chess_board,
                                               value)
    return chess_board, value


def make_move(board, notation, pi_white, pi_black, player, points):
    b = copy.deepcopy(board)
    pi_w = copy.deepcopy(pi_white)
    pi_b = copy.deepcopy(pi_black)

    if player == 1:
        if notation[0:1] == "K":  # moving a king piece
            check_flag1, points_white, points_black = Move_King(b, pi_white.King[0], pi_white.King[1],
                                                                int(notation[1:2]), int(notation[2:3]), player,
                                                                pi_w, pi_b)
            if check_flag1 and not check_attack(b, pi_w.King[0], pi_w.King[1], player, pi_w, pi_b):

                check_flag1, points_white, points_black = Move_King(board, pi_white.King[0], pi_white.King[1],
                                                                    int(notation[1:2]), int(notation[2:3]), player,
                                                                    pi_white, pi_black)
                pi_white.King[0] = int(notation[1:2])
                pi_white.King[1] = int(notation[2:3])
            else:
                print("Invalid Move! Please Do Your Turn Again")
                return False, 0, 0

        elif notation[0:1] == "Q":  # moving a queen piece
            check_flag2, points_white, points_black = Move_Queen(b, pi_white.Queen[0], pi_white.Queen[1],
                                                                 int(notation[1:2]), int(notation[2:3]), player,
                                                                 pi_w, pi_b)
            if check_flag2 and not check_attack(b, pi_w.King[0], pi_w.King[1], player, pi_w, pi_b):

                check_flag2, points_white, points_black = Move_Queen(board, pi_white.Queen[0], pi_white.Queen[1],
                                                                     int(notation[1:2]), int(notation[2:3]), player,
                                                                     pi_white, pi_black)

                pi_white.Queen[0] = int(notation[1:2])
                pi_white.Queen[1] = int(notation[2:3])
            else:
                print("Invalid Move! Please Do Your Turn Again")
                return False, 0, 0

        elif notation[0:1] == "R":  # moving a rook piece
            check_flag3, points_white, points_black = Move_Rook(b, int(notation[1:2]), int(notation[2:3]),
                                                                int(notation[3:4]), int(notation[4:5]), player,
                                                                pi_w, pi_b)
            if check_flag3 and not check_attack(b, pi_w.King[0], pi_w.King[1], player, pi_w, pi_b):

                check_flag3, points_white, points_black = Move_Rook(board, int(notation[1:2]), int(notation[2:3]),
                                                                    int(notation[3:4]), int(notation[4:5]), player,
                                                                    pi_white, pi_black)

                if int(notation[1:2]) == pi_white.Rook[0][0] and int(notation[2:3]) == pi_white.Rook[0][1]:
                    pi_white.Rook[0][0] = int(notation[3:4])
                    pi_white.Rook[0][1] = int(notation[4:5])
                else:
                    pi_white.Rook[1][0] = int(notation[3:4])
                    pi_white.Rook[1][1] = int(notation[4:5])
            else:
                print("Invalid Move! Please Do Your Turn Again")
                return False, 0, 0

        elif notation[0:1] == "B":  # moving a bishop piece
            check_flag4, points_white, points_black = Move_Bishop(b, int(notation[1:2]), int(notation[2:3]),
                                                                  int(notation[3:4]), int(notation[4:5]), player,
                                                                  pi_w, pi_b)
            if check_flag4 and not check_attack(b, pi_w.King[0], pi_w.King[1], player, pi_w, pi_b):

                check_flag4, points_white, points_black = Move_Bishop(board, int(notation[1:2]), int(notation[2:3]),
                                                                      int(notation[3:4]), int(notation[4:5]), player,
                                                                      pi_white, pi_black)

                if int(notation[1:2]) == pi_white.Bishop[0][0] and int(notation[2:3]) == pi_white.Bishop[0][1]:
                    pi_white.Bishop[0][0] = int(notation[3:4])
                    pi_white.Bishop[0][1] = int(notation[4:5])

                else:
                    pi_white.Bishop[1][0] = int(notation[3:4])
                    pi_white.Bishop[1][1] = int(notation[4:5])
            else:
                print("Invalid Move! Please Do Your Turn Again")
                return False, 0, 0

        elif notation[0:1] == "N":  # moving a knight piece
            check_flag5, points_white, points_black = Move_Knight(b, int(notation[1:2]), int(notation[2:3]),
                                                                  int(notation[3:4]), int(notation[4:5]), player,
                                                                  pi_w, pi_b)
            if check_flag5 and not check_attack(b, pi_w.King[0], pi_w.King[1], player, pi_w, pi_b):

                check_flag5, points_white, points_black = Move_Knight(board, int(notation[1:2]), int(notation[2:3]),
                                                                      int(notation[3:4]), int(notation[4:5]), player,
                                                                      pi_white, pi_black)

                if int(notation[1:2]) == pi_white.Knight[0][0] and int(notation[2:3]) == pi_white.Knight[0][1]:
                    pi_white.Knight[0][0] = int(notation[3:4])
                    pi_white.Knight[0][1] = int(notation[4:5])
                else:
                    pi_white.Knight[1][0] = int(notation[3:4])
                    pi_white.Knight[1][1] = int(notation[4:5])
            else:
                print("Invalid Move! Please Do Your Turn Again")
                return False, 0, 0

        else:  # moving a pawn piece
            check_flag6, points_white, points_black = Move_Pawn(b, int(notation[0:1]), int(notation[1:2]),
                                                                int(notation[2:3]), int(notation[3:4]), player,
                                                                pi_w, pi_b)
            if check_flag6 and not check_attack(b, pi_w.King[0], pi_w.King[1], player, pi_w, pi_b):

                check_flag6, points_white, points_black = Move_Pawn(board, int(notation[0:1]), int(notation[1:2]),
                                                                    int(notation[2:3]), int(notation[3:4]), player,
                                                                    pi_white, pi_black)

                for i in range(8):
                    if pi_white.Pawn[i][0] == int(notation[0:1]) and pi_white.Pawn[i][1] == int(notation[1:2]):
                        pi_white.Pawn[i][0] = int(notation[2:3])
                        pi_white.Pawn[i][1] = int(notation[3:4])
                        break
            else:
                print("Invalid Move! Please Do Your Turn Again")
                return False, 0, 0
        return True, points_white, points_black

    else:
        if notation[0:1] == "K":  # moving a king piece
            check_flag1, points_white, points_black = Move_King(b, pi_black.King[0], pi_black.King[1],
                                                                int(notation[1:2]), int(notation[2:3]),
                                                                player, pi_w, pi_b)
            if check_flag1 and not check_attack(b, pi_b.King[0], pi_b.King[1], player, pi_w, pi_b):

                check_flag1, points_white, points_black = Move_King(board, pi_black.King[0], pi_black.King[1],
                                                                    int(notation[1:2]), int(notation[2:3]),
                                                                    player, pi_white, pi_black)

                pi_black.King[0] = int(notation[1:2])
                pi_black.King[1] = int(notation[2:3])
            else:
                print("Invalid Move! Please Do Your Turn Again")
                return False, 0, 0

        elif notation[0:1] == "Q":  # moving a queen piece
            check_flag2, points_white, points_black = Move_Queen(b, pi_black.Queen[0], pi_black.Queen[1],
                                                                 int(notation[1:2]), int(notation[2:3]), player,
                                                                 pi_w, pi_b)
            if check_flag2 and not check_attack(b, pi_b.King[0], pi_b.King[1], player, pi_w, pi_b):

                check_flag2, points_white, points_black = Move_Queen(board, pi_black.Queen[0], pi_black.Queen[1],
                                                                     int(notation[1:2]), int(notation[2:3]), player,
                                                                     pi_white, pi_black)

                pi_black.Queen[0] = int(notation[1:2])
                pi_black.Queen[1] = int(notation[2:3])
            else:
                print("Invalid Move! Please Do Your Turn Again")
                return False, 0, 0

        elif notation[0:1] == "R":  # moving a rook piece
            check_flag3, points_white, points_black = Move_Rook(b, int(notation[1:2]), int(notation[2:3]),
                                                                int(notation[3:4]), int(notation[4:5]), player,
                                                                pi_w, pi_b)
            if check_flag3 and not check_attack(b, pi_b.King[0], pi_b.King[1], player, pi_w, pi_b):

                check_flag3, points_white, points_black = Move_Rook(board, int(notation[1:2]), int(notation[2:3]),
                                                                    int(notation[3:4]), int(notation[4:5]), player,
                                                                    pi_white, pi_black)

                if int(notation[1:2]) == pi_black.Rook[0][0] and int(notation[2:3]) == pi_black.Rook[0][1]:
                    pi_black.Rook[0][0] = int(notation[3:4])
                    pi_black.Rook[0][1] = int(notation[4:5])
                else:
                    pi_black.Rook[1][0] = int(notation[3:4])
                    pi_black.Rook[1][1] = int(notation[4:5])
            else:
                print("Invalid Move! Please Do Your Turn Again")
                return False, 0, 0

        elif notation[0:1] == "B":  # moving a bishop piece
            check_flag4, points_white, points_black = Move_Bishop(b, int(notation[1:2]), int(notation[2:3]),
                                                                  int(notation[3:4]), int(notation[4:5]), player,
                                                                  pi_w, pi_b)
            if check_flag4 and not check_attack(b, pi_b.King[0], pi_b.King[1], player, pi_w, pi_b):

                check_flag4, points_white, points_black = Move_Bishop(board, int(notation[1:2]), int(notation[2:3]),
                                                                      int(notation[3:4]), int(notation[4:5]), player,
                                                                      pi_white, pi_black)

                if int(notation[1:2]) == pi_black.Bishop[0][0] and int(notation[2:3]) == pi_black.Bishop[0][1]:
                    pi_black.Bishop[0][0] = int(notation[3:4])
                    pi_black.Bishop[0][1] = int(notation[4:5])

                else:
                    pi_black.Bishop[1][0] = int(notation[3:4])
                    pi_black.Bishop[1][1] = int(notation[4:5])
            else:
                print("Invalid Move! Please Do Your Turn Again")
                return False, 0, 0

        elif notation[0:1] == "N":  # moving a knight piece
            check_flag5, points_white, points_black = Move_Knight(b, int(notation[1:2]), int(notation[2:3]),
                                                                  int(notation[3:4]), int(notation[4:5]), player,
                                                                  pi_w, pi_b)
            if check_flag5 and not check_attack(b, pi_b.King[0], pi_b.King[1], player, pi_w, pi_b):

                check_flag5, points_white, points_black = Move_Knight(board, int(notation[1:2]), int(notation[2:3]),
                                                                      int(notation[3:4]), int(notation[4:5]), player,
                                                                      pi_white, pi_black)

                if int(notation[1:2]) == pi_black.Knight[0][0] and int(notation[2:3]) == pi_black.Knight[0][1]:
                    pi_black.Knight[0][0] = int(notation[3:4])
                    pi_black.Knight[0][1] = int(notation[4:5])
                else:
                    pi_black.Knight[1][0] = int(notation[3:4])
                    pi_black.Knight[1][1] = int(notation[4:5])
            else:
                print("Invalid Move! Please Do Your Turn Again")
                return False, 0, 0

        else:  # moving a pawn piece
            check_flag6, points_white, points_black = Move_Pawn(b, int(notation[0:1]), int(notation[1:2]),
                                                                int(notation[2:3]), int(notation[3:4]), player,
                                                                pi_w, pi_b)
            if check_flag6 and not check_attack(b, pi_b.King[0], pi_b.King[1], player, pi_w, pi_b):

                check_flag6, points_white, points_black = Move_Pawn(board, int(notation[0:1]), int(notation[1:2]),
                                                                    int(notation[2:3]), int(notation[3:4]), player,
                                                                    pi_white, pi_black)

                for i in range(8):
                    if pi_black.Pawn[i][0] == int(notation[0:1]) and pi_black.Pawn[i][1] == int(notation[1:2]):
                        pi_black.Pawn[i][0] = int(notation[2:3])
                        pi_black.Pawn[i][1] = int(notation[3:4])
                        break
            else:
                print("Invalid Move! Please Do Your Turn Again")
                return False, 0, 0
        return True, points_white, points_black


def Move_Queen(chess_matrix, x1, y1, x2, y2, player, white_piece, black_piece):
    points_white = 0
    points_black = 0

    if x1 == x2 and y1 == y2:
        return False, 0, 0

    if player == 1:  # for white player
        flag = True
        path_len = abs(x1 - x2)

        if chess_matrix[x1][y1] != WHITE_QUEEN:
            flag = False

        elif x1 == x2:  # checking horizontally
            if y1 < y2:
                for i in range(y1, y2 + 1):
                    if chess_matrix[x1][i] == WHITE_KING or chess_matrix[x1][i] == WHITE_ROOK or \
                            chess_matrix[x1][i] == WHITE_KNIGHT or chess_matrix[x1][i] == WHITE_BISHOP or \
                            chess_matrix[x1][i] == WHITE_PAWN:
                        flag = False
                        break

            else:
                for i in range(y2, y1 + 1):
                    if chess_matrix[x1][i] == WHITE_KING or chess_matrix[x1][i] == WHITE_ROOK or \
                            chess_matrix[x1][i] == WHITE_KNIGHT or chess_matrix[x1][i] == WHITE_BISHOP or \
                            chess_matrix[x1][i] == WHITE_PAWN:
                        flag = False
                        break

        elif y1 == y2:  # checking vertically
            if x1 < x2:
                for i in range(x1, x2 + 1):
                    if chess_matrix[i][y2] == WHITE_KING or chess_matrix[i][y2] == WHITE_ROOK or \
                            chess_matrix[i][y2] == WHITE_KNIGHT or chess_matrix[i][y2] == WHITE_BISHOP or \
                            chess_matrix[i][y2] == WHITE_PAWN:
                        flag = False
                        break

            else:
                for i in range(x2, x1 + 1):
                    if chess_matrix[i][y2] == WHITE_KING or chess_matrix[i][y2] == WHITE_ROOK or \
                            chess_matrix[i][y2] == WHITE_KNIGHT or chess_matrix[i][y2] == WHITE_BISHOP or \
                            chess_matrix[i][y2] == WHITE_PAWN:
                        flag = False
                        break

        # checking diagonally
        elif path_len != abs(y1 - y2):
            flag = False

        elif x1 < x2 and y1 < y2:
            tempx = copy.deepcopy(x1)
            tempy = copy.deepcopy(y1)
            for i in range(path_len):
                tempx += 1
                tempy += 1
                if chess_matrix[tempx][tempy] == WHITE_KING or chess_matrix[tempx][tempy] == WHITE_ROOK or \
                        chess_matrix[tempx][tempy] == WHITE_KNIGHT or chess_matrix[tempx][tempy] == WHITE_BISHOP or \
                        chess_matrix[tempx][tempy] == WHITE_PAWN:
                    flag = False
                    break

        elif x1 > x2 and y1 < y2:
            tempx = copy.deepcopy(x1)
            tempy = copy.deepcopy(y1)
            for i in range(path_len):
                tempx -= 1
                tempy += 1
                if chess_matrix[tempx][tempy] == WHITE_KING or chess_matrix[tempx][tempy] == WHITE_ROOK or \
                        chess_matrix[tempx][tempy] == WHITE_KNIGHT or chess_matrix[tempx][tempy] == WHITE_BISHOP or \
                        chess_matrix[tempx][tempy] == WHITE_PAWN:
                    flag = False
                    break

        elif x1 < x2 and y1 > y2:
            tempx = copy.deepcopy(x1)
            tempy = copy.deepcopy(y1)
            for i in range(path_len):
                tempx += 1
                tempy -= 1
                if chess_matrix[tempx][tempy] == WHITE_KING or chess_matrix[tempx][tempy] == WHITE_ROOK or \
                        chess_matrix[tempx][tempy] == WHITE_KNIGHT or chess_matrix[tempx][tempy] == WHITE_BISHOP or \
                        chess_matrix[tempx][tempy] == WHITE_PAWN:
                    flag = False
                    break

        elif x1 > x2 and y1 > y2:
            tempx = copy.deepcopy(x1)
            tempy = copy.deepcopy(y1)
            for i in range(path_len):
                tempx -= 1
                tempy -= 1
                if chess_matrix[tempx][tempy] == WHITE_KING or chess_matrix[tempx][tempy] == WHITE_ROOK or \
                        chess_matrix[tempx][tempy] == WHITE_KNIGHT or chess_matrix[tempx][tempy] == WHITE_BISHOP or \
                        chess_matrix[tempx][tempy] == WHITE_PAWN:
                    flag = False
                    break

        if flag:
            points_white = Calculate_Points_WHITE(chess_matrix, x2, y2, black_piece)
            if points_white == -1:
                print("Invalid Color Piece Movement")
                return False, 0, 0
            else:
                print("Points Earned By Moving Queen By White:- ", points_white)
                chess_matrix[x2][y2] = WHITE_QUEEN
                chess_matrix[x1][y1] = BLANK_SPACE

        return flag, points_white, points_black

    else:  # for black player
        flag = True
        path_len = abs(x1 - x2)

        if chess_matrix[x1][y1] != BLACK_QUEEN:
            flag = False

        elif x1 == x2:  # checking horizontally
            if y1 < y2:
                for i in range(y1, y2 + 1):
                    if chess_matrix[x1][i] == BLACK_KING or chess_matrix[x1][i] == BLACK_ROOK or \
                            chess_matrix[x1][i] == BLACK_KNIGHT or chess_matrix[x1][i] == BLACK_BISHOP or \
                            chess_matrix[x1][i] == BLACK_PAWN:
                        flag = False
                        break

            else:
                for i in range(y2, y1 + 1):
                    if chess_matrix[x1][i] == BLACK_KING or chess_matrix[x1][i] == BLACK_ROOK or \
                            chess_matrix[x1][i] == BLACK_KNIGHT or chess_matrix[x1][i] == BLACK_BISHOP or \
                            chess_matrix[x1][i] == BLACK_PAWN:
                        flag = False
                        break

        elif y1 == y2:  # checking vertically
            if x1 < x2:
                for i in range(x1, x2 + 1):
                    if chess_matrix[i][y2] == BLACK_KING or chess_matrix[i][y2] == BLACK_ROOK or \
                            chess_matrix[i][y2] == BLACK_KNIGHT or chess_matrix[i][y2] == BLACK_BISHOP or \
                            chess_matrix[i][y2] == BLACK_PAWN:
                        flag = False
                        break

            else:
                for i in range(x2, x1 + 1):
                    if chess_matrix[i][y2] == BLACK_KING or chess_matrix[i][y2] == BLACK_ROOK or \
                            chess_matrix[i][y2] == BLACK_KNIGHT or chess_matrix[i][y2] == BLACK_BISHOP or \
                            chess_matrix[i][y2] == BLACK_PAWN:
                        flag = False
                        break

        # checking diagonally
        elif path_len != abs(y1 - y2):
            flag = False

        elif x1 < x2 and y1 < y2:
            tempx = copy.deepcopy(x1)
            tempy = copy.deepcopy(y1)
            for i in range(path_len):
                tempx += 1
                tempy += 1
                if chess_matrix[tempx][tempy] == BLACK_KING or chess_matrix[tempx][tempy] == BLACK_ROOK or \
                        chess_matrix[tempx][tempy] == BLACK_KNIGHT or chess_matrix[tempx][tempy] == BLACK_BISHOP or \
                        chess_matrix[tempx][tempy] == BLACK_PAWN:
                    flag = False
                    break

        elif x1 > x2 and y1 < y2:
            tempx = copy.deepcopy(x1)
            tempy = copy.deepcopy(y1)
            for i in range(path_len):
                tempx -= 1
                tempy += 1
                if chess_matrix[tempx][tempy] == BLACK_KING or chess_matrix[tempx][tempy] == BLACK_ROOK or \
                        chess_matrix[tempx][tempy] == BLACK_KNIGHT or chess_matrix[tempx][tempy] == BLACK_BISHOP or \
                        chess_matrix[tempx][tempy] == BLACK_PAWN:
                    flag = False
                    break

        elif x1 < x2 and y1 > y2:
            tempx = copy.deepcopy(x1)
            tempy = copy.deepcopy(y1)
            for i in range(path_len):
                tempx += 1
                tempy -= 1
                if chess_matrix[tempx][tempy] == BLACK_KING or chess_matrix[tempx][tempy] == BLACK_ROOK or \
                        chess_matrix[tempx][tempy] == BLACK_KNIGHT or chess_matrix[tempx][tempy] == BLACK_BISHOP or \
                        chess_matrix[tempx][tempy] == BLACK_PAWN:
                    flag = False
                    break

        elif x1 > x2 and y1 > y2:
            tempx = copy.deepcopy(x1)
            tempy = copy.deepcopy(y1)
            for i in range(path_len):
                tempx -= 1
                tempy -= 1
                if chess_matrix[tempx][tempy] == BLACK_KING or chess_matrix[tempx][tempy] == BLACK_ROOK or \
                        chess_matrix[tempx][tempy] == BLACK_KNIGHT or chess_matrix[tempx][tempy] == BLACK_BISHOP or \
                        chess_matrix[tempx][tempy] == BLACK_PAWN:
                    flag = False
                    break

        if flag:
            points_black = Calculate_Points_BLACK(chess_matrix, x2, y2, white_piece)
            if points_black == -1:
                print("Invalid Color Piece Movement")
                return False, 0, 0
            else:
                print("Points Earned By Moving Queen By Black:- ", points_black)
                chess_matrix[x2][y2] = BLACK_QUEEN
                chess_matrix[x1][y1] = BLANK_SPACE

        return flag, points_white, points_black


def Move_Queen_Check(chess_matrix, x1, y1, x2, y2, player, white_piece, black_piece):
    # for black player
    flag = True
    path_len = abs(x1 - x2)

    if x1 == x2 and y1 == y2:
        return False

    if chess_matrix[x1][y1] != BLACK_QUEEN:
        flag = False

    elif x1 == x2:  # checking horizontally
        if y1 < y2:
            for i in range(y1, y2 + 1):
                if chess_matrix[x1][i] == BLACK_KING or chess_matrix[x1][i] == BLACK_ROOK or \
                        chess_matrix[x1][i] == BLACK_KNIGHT or chess_matrix[x1][i] == BLACK_BISHOP or \
                        chess_matrix[x1][i] == BLACK_PAWN:
                    flag = False
                    break

        else:
            for i in range(y2, y1 + 1):
                if chess_matrix[x1][i] == BLACK_KING or chess_matrix[x1][i] == BLACK_ROOK or \
                        chess_matrix[x1][i] == BLACK_KNIGHT or chess_matrix[x1][i] == BLACK_BISHOP or \
                        chess_matrix[x1][i] == BLACK_PAWN:
                    flag = False
                    break

    elif y1 == y2:  # checking vertically
        if x1 < x2:
            for i in range(x1, x2 + 1):
                if chess_matrix[i][y2] == BLACK_KING or chess_matrix[i][y2] == BLACK_ROOK or \
                        chess_matrix[i][y2] == BLACK_KNIGHT or chess_matrix[i][y2] == BLACK_BISHOP or \
                        chess_matrix[i][y2] == BLACK_PAWN:
                    flag = False
                    break

        else:
            for i in range(x2, x1 + 1):
                if chess_matrix[i][y2] == BLACK_KING or chess_matrix[i][y2] == BLACK_ROOK or \
                        chess_matrix[i][y2] == BLACK_KNIGHT or chess_matrix[i][y2] == BLACK_BISHOP or \
                        chess_matrix[i][y2] == BLACK_PAWN:
                    flag = False
                    break

    # checking diagonally
    elif path_len != abs(y1 - y2):
        flag = False

    elif x1 < x2 and y1 < y2:
        tempx = copy.deepcopy(x1)
        tempy = copy.deepcopy(y1)
        for i in range(path_len):
            tempx += 1
            tempy += 1
            if chess_matrix[tempx][tempy] == BLACK_KING or chess_matrix[tempx][tempy] == BLACK_ROOK or \
                    chess_matrix[tempx][tempy] == BLACK_KNIGHT or chess_matrix[tempx][tempy] == BLACK_BISHOP or \
                    chess_matrix[tempx][tempy] == BLACK_PAWN:
                flag = False
                break

    elif x1 > x2 and y1 < y2:
        tempx = copy.deepcopy(x1)
        tempy = copy.deepcopy(y1)
        for i in range(path_len):
            tempx -= 1
            tempy += 1
            if chess_matrix[tempx][tempy] == BLACK_KING or chess_matrix[tempx][tempy] == BLACK_ROOK or \
                    chess_matrix[tempx][tempy] == BLACK_KNIGHT or chess_matrix[tempx][tempy] == BLACK_BISHOP or \
                    chess_matrix[tempx][tempy] == BLACK_PAWN:
                flag = False
                break

    elif x1 < x2 and y1 > y2:
        tempx = copy.deepcopy(x1)
        tempy = copy.deepcopy(y1)
        for i in range(path_len):
            tempx += 1
            tempy -= 1
            if chess_matrix[tempx][tempy] == BLACK_KING or chess_matrix[tempx][tempy] == BLACK_ROOK or \
                    chess_matrix[tempx][tempy] == BLACK_KNIGHT or chess_matrix[tempx][tempy] == BLACK_BISHOP or \
                    chess_matrix[tempx][tempy] == BLACK_PAWN:
                flag = False
                break

    elif x1 > x2 and y1 > y2:
        tempx = copy.deepcopy(x1)
        tempy = copy.deepcopy(y1)
        for i in range(path_len):
            tempx -= 1
            tempy -= 1
            if chess_matrix[tempx][tempy] == BLACK_KING or chess_matrix[tempx][tempy] == BLACK_ROOK or \
                    chess_matrix[tempx][tempy] == BLACK_KNIGHT or chess_matrix[tempx][tempy] == BLACK_BISHOP or \
                    chess_matrix[tempx][tempy] == BLACK_PAWN:
                flag = False
                break

    if flag:
        chess_matrix[x2][y2] = BLACK_QUEEN
        chess_matrix[x1][y1] = BLANK_SPACE
    return flag


def Move_King(chess_matrix, x1, y1, x2, y2, player, white_piece, black_piece):
    points_white = 0
    points_black = 0
    if x2 < 0 or y2 < 0 or x2 >= 8 or y2 >= 8:
        return False

    if x1 == x2 and y1 == y2:
        return False, 0, 0

    if player == 1:
        flag = True
        if (x1 + 1 == x2 and y1 + 1 == y2) or (x1 - 1 == x2 and y1 + 1 == y2) or (x1 + 1 == x2 and y1 - 1 == y2) or \
                (x1 - 1 == x2 and y1 - 1 == y2) or (x1 + 1 == x2 and y1 == y2) or (x1 - 1 == x2 and y1 == y2) or \
                (x1 == x2 and y1 - 1 == y2) or (x1 == x2 and y1 - 1 == y2):
            if chess_matrix[x2][y2] == WHITE_KNIGHT or chess_matrix[x2][y2] == WHITE_QUEEN or \
                    chess_matrix[x2][y2] == WHITE_ROOK or chess_matrix[x2][y2] == WHITE_KING or \
                    chess_matrix[x2][y2] == WHITE_BISHOP or chess_matrix[x2][y2] == WHITE_PAWN:
                flag = False
        else:
            flag = False

        if check_attack(chess_matrix, x2, y2, player, white_piece, black_piece):
            flag = False

        if flag:
            points_white = Calculate_Points_WHITE(chess_matrix, x2, y2, black_piece)
            if points_white == -1:
                print("Invalid Color Piece Movement")
                return False, 0, 0
            else:
                print("Points Earned By Moving King By White:- ", points_white)
                chess_matrix[x1][y1] = BLANK_SPACE
                chess_matrix[x2][y2] = WHITE_KING

        return flag, points_white, points_black

    else:
        flag = True
        if (x1 + 1 == x2 and y1 + 1 == y2) or (x1 - 1 == x2 and y1 + 1 == y2) or (x1 + 1 == x2 and y1 - 1 == y2) or \
                (x1 - 1 == x2 and y1 - 1 == y2) or (x1 + 1 == x2 and y1 == y2) or (x1 - 1 == x2 and y1 == y2) or \
                (x1 == x2 and y1 - 1 == y2) or (x1 == x2 and y1 - 1 == y2):
            if chess_matrix[x2][y2] == BLACK_KNIGHT or chess_matrix[x2][y2] == BLACK_QUEEN or \
                    chess_matrix[x2][y2] == BLACK_ROOK or chess_matrix[x2][y2] == BLACK_KING or \
                    chess_matrix[x2][y2] == BLACK_BISHOP or chess_matrix[x2][y2] == BLACK_PAWN:
                flag = False
        else:
            flag = False

        if check_attack(chess_matrix, x2, y2, player, white_piece, black_piece):
            flag = False

        if flag:
            points_black = Calculate_Points_BLACK(chess_matrix, x2, y2, white_piece)
            if points_black == -1:
                print("Invalid Color Piece Movement")
                return False, 0, 0
            else:
                print("Points Earned By Moving King By Black:- ", points_black)
                chess_matrix[x1][y1] = BLANK_SPACE
                chess_matrix[x2][y2] = BLACK_KING

        return flag, points_white, points_black


def Move_King_Check(chess_matrix, x1, y1, x2, y2, player, white_piece, black_piece):
    if x2 < 0 or y2 < 0 or x2 >= 8 or y2 >= 8:
        return False

    if x1 == x2 and y1 == y2:
        return False

    flag = True
    if chess_matrix[x2][y2] == BLACK_KNIGHT or chess_matrix[x2][y2] == BLACK_QUEEN or \
            chess_matrix[x2][y2] == BLACK_ROOK or chess_matrix[x2][y2] == BLACK_KING or \
            chess_matrix[x2][y2] == BLACK_BISHOP or chess_matrix[x2][y2] == BLACK_PAWN:
        flag = False

    if (x1 + 1 == x2 and y1 + 1 == y2) or (x1 - 1 == x2 and y1 + 1 == y2) or (x1 + 1 == x2 and y1 - 1 == y2) or \
            (x1 - 1 == x2 and y1 - 1 == y2) or (x1 + 1 == x2 and y1 == y2) or (x1 - 1 == x2 and y1 == y2) or \
            (x1 == x2 and y1 - 1 == y2) or (x1 == x2 and y1 - 1 == y2):
        if chess_matrix[x2][y2] == BLACK_KNIGHT or chess_matrix[x2][y2] == BLACK_QUEEN or \
                chess_matrix[x2][y2] == BLACK_ROOK or chess_matrix[x2][y2] == BLACK_KING or \
                chess_matrix[x2][y2] == BLACK_BISHOP or chess_matrix[x2][y2] == BLACK_PAWN:
            flag = False

    else:
        flag = False

    if check_attack(chess_matrix, x2, y2, player, white_piece, black_piece):
        flag = False

    if flag:
        chess_matrix[x1][y1] = BLANK_SPACE
        chess_matrix[x2][y2] = BLACK_KING
    return flag


def Move_Rook(chess_matrix, x1, y1, x2, y2, player, white_piece, black_piece):
    points_white = 0
    points_black = 0

    if x1 == x2 and y1 == y2:
        return False, 0, 0

    if player == 1:  # for white player
        flag = True

        if chess_matrix[x1][y1] != WHITE_ROOK:
            flag = False

        elif x1 == x2:  # checking horizontally
            if y1 < y2:
                for i in range(y1 + 1, y2 + 1):
                    if chess_matrix[x1][i] == WHITE_KING or chess_matrix[x1][i] == WHITE_QUEEN or \
                            chess_matrix[x1][i] == WHITE_KNIGHT or chess_matrix[x1][i] == WHITE_BISHOP or \
                            chess_matrix[x1][i] == WHITE_PAWN or chess_matrix[x1][i] == WHITE_ROOK:
                        flag = False
                        break

            else:
                for i in range(y2, y1):
                    if chess_matrix[x1][i] == WHITE_KING or chess_matrix[x1][i] == WHITE_QUEEN or \
                            chess_matrix[x1][i] == WHITE_KNIGHT or chess_matrix[x1][i] == WHITE_BISHOP or \
                            chess_matrix[x1][i] == WHITE_PAWN or chess_matrix[x1][i] == WHITE_ROOK:
                        flag = False
                        break

        elif y1 == y2:  # checking vertically
            if x1 < x2:
                for i in range(x1 + 1, x2 + 1):
                    if chess_matrix[i][y2] == WHITE_KING or chess_matrix[i][y2] == WHITE_QUEEN or \
                            chess_matrix[i][y2] == WHITE_KNIGHT or chess_matrix[i][y2] == WHITE_BISHOP or \
                            chess_matrix[i][y2] == WHITE_PAWN or chess_matrix[i][y2] == WHITE_ROOK:
                        flag = False
                        break

            else:
                for i in range(x2, x1):
                    if chess_matrix[i][y2] == WHITE_KING or chess_matrix[i][y2] == WHITE_QUEEN or \
                            chess_matrix[i][y2] == WHITE_KNIGHT or chess_matrix[i][y2] == WHITE_BISHOP or \
                            chess_matrix[i][y2] == WHITE_PAWN or chess_matrix[i][y2] == WHITE_ROOK:
                        flag = False
                        break

        if flag:
            points_white = Calculate_Points_WHITE(chess_matrix, x2, y2, black_piece)
            if points_white == -1:
                print("Invalid Color Piece Movement")
                return False, 0, 0
            else:
                print("Points Earned By Moving Rook By White:- ", points_white)
                chess_matrix[x2][y2] = WHITE_ROOK
                chess_matrix[x1][y1] = BLANK_SPACE

        return flag, points_white, points_black

    else:
        flag = True

        if chess_matrix[x1][y1] != BLACK_ROOK:
            flag = False

        elif x1 == x2:  # checking horizontally
            if y1 < y2:
                for i in range(y1 + 1, y2 + 1):
                    if chess_matrix[x1][i] == BLACK_KING or chess_matrix[x1][i] == BLACK_QUEEN or \
                            chess_matrix[x1][i] == BLACK_KNIGHT or chess_matrix[x1][i] == BLACK_BISHOP or \
                            chess_matrix[x1][i] == BLACK_PAWN or chess_matrix[x1][i] == BLACK_ROOK:
                        flag = False
                        break

            else:
                for i in range(y2, y1 + 1):
                    if chess_matrix[x1][i] == BLACK_KING or chess_matrix[x1][i] == BLACK_QUEEN or \
                            chess_matrix[x1][i] == BLACK_KNIGHT or chess_matrix[x1][i] == BLACK_BISHOP or \
                            chess_matrix[x1][i] == BLACK_PAWN or chess_matrix[x1][i] == BLACK_ROOK:
                        flag = False
                        break

        elif y1 == y2:  # checking vertically
            if x1 < x2:
                for i in range(x1, x2 + 1):
                    if chess_matrix[i][y2] == BLACK_KING or chess_matrix[i][y2] == BLACK_QUEEN or \
                            chess_matrix[i][y2] == BLACK_KNIGHT or chess_matrix[i][y2] == BLACK_BISHOP or \
                            chess_matrix[i][y2] == BLACK_PAWN or chess_matrix[i][y2] == BLACK_ROOK:
                        flag = False
                        break

            else:
                for i in range(x2, x1 + 1):
                    if chess_matrix[i][y2] == BLACK_KING or chess_matrix[i][y2] == BLACK_QUEEN or \
                            chess_matrix[i][y2] == BLACK_KNIGHT or chess_matrix[i][y2] == BLACK_BISHOP or \
                            chess_matrix[i][y2] == BLACK_PAWN or chess_matrix[i][y2] == BLACK_ROOK:
                        flag = False
                        break

        if flag:
            points_black = Calculate_Points_BLACK(chess_matrix, x2, y2, white_piece)
            if points_black == -1:
                print("Invalid Color Piece Movement")
                return False, 0, 0
            else:
                print("Points Earned By Moving Rook By Black:- ", points_black)
                chess_matrix[x2][y2] = BLACK_ROOK
                chess_matrix[x1][y1] = BLANK_SPACE

        return flag, points_white, points_black


def Move_Rook_Check(chess_matrix, x1, y1, x2, y2):
    flag = True

    if chess_matrix[x1][y1] != BLACK_ROOK:
        flag = False

    elif x1 == x2:  # checking horizontally
        if y1 < y2:
            for i in range(y1 + 1, y2 + 1):
                if chess_matrix[x1][i] == BLACK_KING or chess_matrix[x1][i] == BLACK_QUEEN or \
                        chess_matrix[x1][i] == BLACK_KNIGHT or chess_matrix[x1][i] == BLACK_BISHOP or \
                        chess_matrix[x1][i] == BLACK_PAWN or chess_matrix[x1][i] == BLACK_ROOK:
                    flag = False
                    break

        else:
            for i in range(y2, y1 + 1):
                if chess_matrix[x1][i] == BLACK_KING or chess_matrix[x1][i] == BLACK_QUEEN or \
                        chess_matrix[x1][i] == BLACK_KNIGHT or chess_matrix[x1][i] == BLACK_BISHOP or \
                        chess_matrix[x1][i] == BLACK_PAWN or chess_matrix[x1][i] == BLACK_ROOK:
                    flag = False
                    break

    elif y1 == y2:  # checking vertically
        if x1 < x2:
            for i in range(x1, x2 + 1):
                if chess_matrix[i][y2] == BLACK_KING or chess_matrix[i][y2] == BLACK_QUEEN or \
                        chess_matrix[i][y2] == BLACK_KNIGHT or chess_matrix[i][y2] == BLACK_BISHOP or \
                        chess_matrix[i][y2] == BLACK_PAWN or chess_matrix[i][y2] == BLACK_ROOK:
                    flag = False
                    break

        else:
            for i in range(x2, x1 + 1):
                if chess_matrix[i][y2] == BLACK_KING or chess_matrix[i][y2] == BLACK_QUEEN or \
                        chess_matrix[i][y2] == BLACK_KNIGHT or chess_matrix[i][y2] == BLACK_BISHOP or \
                        chess_matrix[i][y2] == BLACK_PAWN or chess_matrix[i][y2] == BLACK_ROOK:
                    flag = False
                    break

    return flag


def Move_Knight(chess_matrix, x1, y1, x2, y2, player, white_piece, black_piece):
    points_white = 0
    points_black = 0

    if x1 == x2 and y1 == y2:
        return False, 0, 0

    if player == 1:
        flag = True
        if (x1 + 2 == x2 and y1 + 1 == y2) or (x1 + 1 == x2 and y1 + 2 == y2) or (x1 - 2 == x2 and y1 + 1 == y2) or \
                (x1 - 1 == x2 and y1 + 2 == y2) or (x1 + 2 == x2 and y1 - 1 == y2) or \
                (x1 + 1 == x2 and y1 - 2 == y2) or (x1 - 2 == x2 and y1 - 1 == y2) or (x1 - 1 == x2 and y1 - 2 == y2):
            if chess_matrix[x2][y2] == WHITE_KNIGHT or chess_matrix[x2][y2] == WHITE_QUEEN or \
                    chess_matrix[x2][y2] == WHITE_ROOK or chess_matrix[x2][y2] == WHITE_KING or \
                    chess_matrix[x2][y2] == WHITE_BISHOP or chess_matrix[x2][y2] == WHITE_PAWN:
                flag = False
        else:
            flag = False

        if flag:
            points_white = Calculate_Points_WHITE(chess_matrix, x2, y2, black_piece)
            if points_white == -1:
                print("Invalid Color Piece Movement")
                return False, 0, 0
            else:
                print("Points Earned By Moving Knight By White:- ", points_white)
                chess_matrix[x1][y1] = BLANK_SPACE
                chess_matrix[x2][y2] = WHITE_KNIGHT

        return flag, points_white, points_black

    else:
        flag = True
        if (x1 + 2 == x2 and y1 + 1 == y2) or (x1 + 1 == x2 and y1 + 2 == y2) or (x1 - 2 == x2 and y1 + 1 == y2) or \
                (x1 - 1 == x2 and y1 + 2 == y2) or (x1 + 2 == x2 and y1 - 1 == y2) or \
                (x1 + 1 == x2 and y1 - 2 == y2) or (x1 - 2 == x2 and y1 - 1 == y2) or (x1 - 1 == x2 and y1 - 2 == y2):
            if chess_matrix[x2][y2] == BLACK_KNIGHT or chess_matrix[x2][y2] == BLACK_QUEEN or \
                    chess_matrix[x2][y2] == BLACK_ROOK or chess_matrix[x2][y2] == BLACK_KING or \
                    chess_matrix[x2][y2] == BLACK_BISHOP or chess_matrix[x2][y2] == BLACK_PAWN:
                flag = False
        else:
            flag = False

        if flag:
            points_black = Calculate_Points_BLACK(chess_matrix, x2, y2, white_piece)
            if points_black == -1:
                print("Invalid Color Piece Movement")
                return False, 0, 0
            else:
                print("Points Earned By Moving Knight By Black:- ", points_black)
                chess_matrix[x1][y1] = BLANK_SPACE
                chess_matrix[x2][y2] = BLACK_KNIGHT

        return flag, points_white, points_black


def Move_Knight_Check(chess_matrix, x1, y1, x2, y2):
    flag = True

    if x1 == x2 and y1 == y2:
        return False

    if (x1 + 2 == x2 and y1 + 1 == y2) or (x1 + 1 == x2 and y1 + 2 == y2) or (x1 - 2 == x2 and y1 + 1 == y2) or \
            (x1 - 1 == x2 and y1 + 2 == y2) or (x1 + 2 == x2 and y1 - 1 == y2) or (x1 + 1 == x2 and y1 - 2 == y2) or \
            (x1 - 2 == x2 and y1 - 1 == y2) or (x1 - 1 == x2 and y1 - 2 == y2):
        if chess_matrix[x2][y2] == BLACK_KNIGHT or chess_matrix[x2][y2] == BLACK_QUEEN or \
                chess_matrix[x2][y2] == BLACK_ROOK or chess_matrix[x2][y2] == BLACK_KING or \
                chess_matrix[x2][y2] == BLACK_BISHOP or chess_matrix[x2][y2] == BLACK_PAWN:
            flag = False
    else:
        flag = False

    if flag:
        chess_matrix[x1][y1] = BLANK_SPACE
        chess_matrix[x2][y2] = BLACK_KNIGHT

    return flag


def Move_Bishop(chess_matrix, x1, y1, x2, y2, player, white_piece, black_piece):
    points_white = 0
    points_black = 0

    if x1 == x2 and y1 == y2:
        return False, 0, 0

    if player == 1:  # for white player
        flag = True
        path_len = abs(x1 - x2)

        if chess_matrix[x1][y1] != WHITE_BISHOP:
            flag = False

        if path_len != abs(y1 - y2):
            flag = False

        elif x1 < x2 and y1 < y2:
            tempx = x1
            tempy = y1
            for i in range(path_len):
                tempx += 1
                tempy += 1
                if chess_matrix[tempx][tempy] == WHITE_KING or chess_matrix[tempx][tempy] == WHITE_ROOK or \
                        chess_matrix[tempx][tempy] == WHITE_KNIGHT or chess_matrix[tempx][tempy] == WHITE_QUEEN or \
                        chess_matrix[tempx][tempy] == WHITE_PAWN:
                    flag = False
                    break

        elif x1 > x2 and y1 < y2:
            tempx = x1
            tempy = y1
            for i in range(path_len):
                tempx -= 1
                tempy += 1
                if chess_matrix[tempx][tempy] == WHITE_KING or chess_matrix[tempx][tempy] == WHITE_ROOK or \
                        chess_matrix[tempx][tempy] == WHITE_KNIGHT or chess_matrix[tempx][tempy] == WHITE_QUEEN or \
                        chess_matrix[tempx][tempy] == WHITE_PAWN:
                    flag = False
                    break

        elif x1 < x2 and y1 > y2:
            tempx = x1
            tempy = y1
            for i in range(path_len):
                tempx += 1
                tempy -= 1
                if chess_matrix[tempx][tempy] == WHITE_KING or chess_matrix[tempx][tempy] == WHITE_ROOK or \
                        chess_matrix[tempx][tempy] == WHITE_KNIGHT or chess_matrix[tempx][tempy] == WHITE_QUEEN or \
                        chess_matrix[tempx][tempy] == WHITE_PAWN:
                    flag = False
                    break

        elif x1 > x2 and y1 > y2:
            tempx = x1
            tempy = y1
            for i in range(path_len):
                tempx -= 1
                tempy -= 1
                if chess_matrix[tempx][tempy] == WHITE_KING or chess_matrix[tempx][tempy] == WHITE_ROOK or \
                        chess_matrix[tempx][tempy] == WHITE_KNIGHT or chess_matrix[tempx][tempy] == WHITE_QUEEN or \
                        chess_matrix[tempx][tempy] == WHITE_PAWN:
                    flag = False
                    break

        if flag:
            points_white = Calculate_Points_WHITE(chess_matrix, x2, y2, black_piece)
            if points_white == -1:
                print("Invalid Color Piece Movement")
                return False, 0, 0
            else:
                print("Points Earned By Moving Bishop By White:- ", points_white)
                chess_matrix[x2][y2] = WHITE_BISHOP
                chess_matrix[x1][y1] = BLANK_SPACE

        return flag, points_white, points_black

    else:
        flag = True
        path_len = abs(x1 - x2)

        if chess_matrix[x1][y1] != BLACK_BISHOP:
            flag = False

        if path_len != abs(y1 - y2):
            flag = False

        elif x1 < x2 and y1 < y2:
            tempx = x1
            tempy = y1
            for i in range(path_len):
                tempx += 1
                tempy += 1
                if chess_matrix[tempx][tempy] == BLACK_KING or chess_matrix[tempx][tempy] == BLACK_ROOK or \
                        chess_matrix[tempx][tempy] == BLACK_KNIGHT or chess_matrix[tempx][tempy] == BLACK_BISHOP or \
                        chess_matrix[tempx][tempy] == BLACK_PAWN:
                    flag = False
                    break

        elif x1 > x2 and y1 < y2:
            tempx = x1
            tempy = y1
            for i in range(path_len):
                tempx -= 1
                tempy += 1
                if chess_matrix[tempx][tempy] == BLACK_KING or chess_matrix[tempx][tempy] == BLACK_ROOK or \
                        chess_matrix[tempx][tempy] == BLACK_KNIGHT or chess_matrix[tempx][tempy] == BLACK_BISHOP or \
                        chess_matrix[tempx][tempy] == BLACK_PAWN:
                    flag = False
                    break

        elif x1 < x2 and y1 > y2:
            tempx = x1
            tempy = y1
            for i in range(path_len):
                tempx += 1
                tempy -= 1
                if chess_matrix[tempx][tempy] == BLACK_KING or chess_matrix[tempx][tempy] == BLACK_ROOK or \
                        chess_matrix[tempx][tempy] == BLACK_KNIGHT or chess_matrix[tempx][tempy] == BLACK_BISHOP or \
                        chess_matrix[tempx][tempy] == BLACK_PAWN:
                    flag = False
                    break

        elif x1 > x2 and y1 > y2:
            tempx = x1
            tempy = y1
            for i in range(path_len):
                tempx -= 1
                tempy -= 1
                if chess_matrix[tempx][tempy] == BLACK_KING or chess_matrix[tempx][tempy] == BLACK_ROOK or \
                        chess_matrix[tempx][tempy] == BLACK_KNIGHT or chess_matrix[tempx][tempy] == BLACK_BISHOP or \
                        chess_matrix[tempx][tempy] == BLACK_PAWN:
                    flag = False
                    break

        if flag:
            points_black = Calculate_Points_BLACK(chess_matrix, x2, y2, white_piece)
            if points_black == -1:
                print("Invalid Color Piece Movement")
                return False, 0, 0
            else:
                print("Points Earned By Moving Bishop By Black:- ", points_black)
                chess_matrix[x2][y2] = BLACK_QUEEN
                chess_matrix[x1][y1] = BLANK_SPACE

        return flag, points_white, points_black


def Move_Bishop_Check(chess_matrix, x1, y1, x2, y2, player, white_piece, black_piece):
    flag = True
    path_len = abs(x1 - x2)

    if x1 == x2 and y1 == y2:
        return False

    if chess_matrix[x1][y1] != BLACK_BISHOP:
        flag = False

    if path_len != abs(y1 - y2):
        flag = False

    elif x1 < x2 and y1 < y2:
        tempx = x1
        tempy = y1
        for i in range(path_len):
            tempx += 1
            tempy += 1
            if chess_matrix[tempx][tempy] == BLACK_KING or chess_matrix[tempx][tempy] == BLACK_ROOK or \
                    chess_matrix[tempx][tempy] == BLACK_KNIGHT or chess_matrix[tempx][tempy] == BLACK_BISHOP or \
                    chess_matrix[tempx][tempy] == BLACK_PAWN:
                flag = False
                break

    elif x1 > x2 and y1 < y2:
        tempx = x1
        tempy = y1
        for i in range(path_len):
            tempx -= 1
            tempy += 1
            if chess_matrix[tempx][tempy] == BLACK_KING or chess_matrix[tempx][tempy] == BLACK_ROOK or \
                    chess_matrix[tempx][tempy] == BLACK_KNIGHT or chess_matrix[tempx][tempy] == BLACK_BISHOP or \
                    chess_matrix[tempx][tempy] == BLACK_PAWN:
                flag = False
                break

    elif x1 < x2 and y1 > y2:
        tempx = x1
        tempy = y1
        for i in range(path_len):
            tempx += 1
            tempy -= 1
            if chess_matrix[tempx][tempy] == BLACK_KING or chess_matrix[tempx][tempy] == BLACK_ROOK or \
                    chess_matrix[tempx][tempy] == BLACK_KNIGHT or chess_matrix[tempx][tempy] == BLACK_BISHOP or \
                    chess_matrix[tempx][tempy] == BLACK_PAWN:
                flag = False
                break

    elif x1 > x2 and y1 > y2:
        tempx = x1
        tempy = y1
        for i in range(path_len):
            tempx -= 1
            tempy -= 1
            if chess_matrix[tempx][tempy] == BLACK_KING or chess_matrix[tempx][tempy] == BLACK_ROOK or \
                    chess_matrix[tempx][tempy] == BLACK_KNIGHT or chess_matrix[tempx][tempy] == BLACK_BISHOP or \
                    chess_matrix[tempx][tempy] == BLACK_PAWN:
                flag = False
                break

    if flag:
        chess_matrix[x2][y2] = BLACK_QUEEN
        chess_matrix[x1][y1] = BLANK_SPACE
    return flag


def Move_Pawn(chess_matrix, x1, y1, x2, y2, player, white_piece, black_piece):
    points_white = 0
    points_black = 0

    if x1 == x2 and y1 == y2:
        return False, 0, 0

    if player == 1:  # for white player
        flag = True
        temp = 0

        if x1 < x2:
            return False

        if chess_matrix[x1][y1] != WHITE_PAWN:
            return False

        else:
            for i in range(8):
                if white_piece.Pawn[i][0] == x1 and white_piece.Pawn[i][1] == y1:
                    temp = i
                    break

            if y1 != y2:
                if (y2 == y1 - 1 and x2 == x1 - 1) or (y2 == y1 + 1 and x2 == x1 - 1):
                    if (chess_matrix[x2][y2] != BLACK_KNIGHT and chess_matrix[x2][y2] != BLACK_BISHOP and
                            chess_matrix[x2][y2] != BLACK_KING and chess_matrix[x2][y2] != BLACK_ROOK and
                            chess_matrix[x2][y2] != BLACK_QUEEN and chess_matrix[x2][y2] != BLACK_PAWN):
                        flag = False
                else:
                    flag = False

            elif chess_matrix[x2][y2] == BLACK_KNIGHT or chess_matrix[x2][y2] == BLACK_BISHOP or \
                    chess_matrix[x2][y2] == BLACK_KING or chess_matrix[x2][y2] == BLACK_ROOK or \
                    chess_matrix[x2][y2] == BLACK_QUEEN or chess_matrix[x2][y2] == BLACK_PAWN or \
                    chess_matrix[x2][y2] == WHITE_KNIGHT or chess_matrix[x2][y2] == WHITE_BISHOP or \
                    chess_matrix[x2][y2] == WHITE_KING or chess_matrix[x2][y2] == WHITE_ROOK or \
                    chess_matrix[x2][y2] == WHITE_QUEEN or chess_matrix[x2][y2] == WHITE_PAWN:
                flag = False

            elif white_piece.Pawn_flag[temp]:
                if x2 < x1 - 2:
                    flag = False

            else:
                if x2 < x1 - 1:
                    flag = False

        if flag:
            points_white = Calculate_Points_WHITE(chess_matrix, x2, y2, black_piece)
            if points_white == -1:
                print("Invalid Color Piece Movement")
                return False, None, None
            else:
                print("Points Earned By Moving Pawn By White:- ", points_white)
                chess_matrix[x1][y1] = BLANK_SPACE
                chess_matrix[x2][y2] = WHITE_PAWN
                white_piece.Pawn_flag[temp] = False

        return flag, points_white, points_black

    else:  # for black player
        flag = True
        temp = 0

        if x1 > x2:
            return False

        if chess_matrix[x1][y1] != BLACK_PAWN:
            return False

        else:
            for i in range(8):
                if black_piece.Pawn[i][0] == x1 and black_piece.Pawn[i][1] == y1:
                    temp = i
                    break

            if y1 != y2:
                if (y2 == y1 - 1 and x2 == x1 + 1) or (y2 == y1 + 1 and x2 == x1 + 1):
                    if (chess_matrix[x2][y2] != WHITE_KNIGHT and chess_matrix[x2][y2] != WHITE_BISHOP and
                            chess_matrix[x2][y2] != WHITE_KING and chess_matrix[x2][y2] != WHITE_ROOK and
                            chess_matrix[x2][y2] != WHITE_QUEEN and chess_matrix[x2][y2] != WHITE_PAWN):
                        flag = False
                else:
                    flag = False

            if black_piece.Pawn_flag[temp]:
                if x2 > x1 + 2:
                    flag = False

            else:
                if x2 > x1 + 1:
                    flag = False

            if chess_matrix[x2][y2] == WHITE_KNIGHT or chess_matrix[x2][y2] == WHITE_BISHOP or \
                    chess_matrix[x2][y2] == WHITE_KING or chess_matrix[x2][y2] == WHITE_ROOK or \
                    chess_matrix[x2][y2] == WHITE_QUEEN or chess_matrix[x2][y2] == WHITE_PAWN or \
                    chess_matrix[x2][y2] == BLACK_KNIGHT or chess_matrix[x2][y2] == BLACK_BISHOP or \
                    chess_matrix[x2][y2] == BLACK_KING or chess_matrix[x2][y2] == BLACK_ROOK or \
                    chess_matrix[x2][y2] == BLACK_QUEEN or chess_matrix[x2][y2] == BLACK_PAWN:
                flag = False

        if flag:
            points_black = Calculate_Points_BLACK(chess_matrix, x2, y2, white_piece)
            if points_black == -1:
                print("Invalid Color Piece Movement")
                return False, 0, 0
            else:
                print("Points Earned By Moving Pawn By Black:- ", points_black)
                chess_matrix[x1][y1] = BLANK_SPACE
                chess_matrix[x2][y2] = BLACK_PAWN
                black_piece.Pawn_flag[temp] = False

        return flag, points_white, points_black


def Move_Pawn_Check(chess_matrix, x1, y1, x2, y2, player, white_piece, black_piece):
    flag = True
    temp = 0

    if x1 == x2 and y1 == y2:
        return False

    if x1 > x2:
        return False

    if chess_matrix[x1][y1] != BLACK_PAWN:
        return False

    else:
        for i in range(8):
            if black_piece.Pawn[i][0] == x1 and black_piece.Pawn[i][1] == y1:
                temp = i
                break

        if y1 != y2:
            if (y2 == y1 - 1 and x2 == x1 + 1) or (y2 == y1 + 1 and x2 == x1 + 1):
                if (chess_matrix[x2][y2] != WHITE_KNIGHT and chess_matrix[x2][y2] != WHITE_BISHOP and
                        chess_matrix[x2][y2] != WHITE_KING and chess_matrix[x2][y2] != WHITE_ROOK and
                        chess_matrix[x2][y2] != WHITE_QUEEN and chess_matrix[x2][y2] != WHITE_PAWN):
                    flag = False
            else:
                flag = False

        if black_piece.Pawn_flag[temp]:
            if x2 > x1 + 2:
                flag = False

        else:
            if x2 > x1 + 1:
                flag = False

        if chess_matrix[x2][y2] == WHITE_KNIGHT or chess_matrix[x2][y2] == WHITE_BISHOP or \
                chess_matrix[x2][y2] == WHITE_KING or chess_matrix[x2][y2] == WHITE_ROOK or \
                chess_matrix[x2][y2] == WHITE_QUEEN or chess_matrix[x2][y2] == WHITE_PAWN or \
                chess_matrix[x2][y2] == BLACK_KNIGHT or chess_matrix[x2][y2] == BLACK_BISHOP or \
                chess_matrix[x2][y2] == BLACK_KING or chess_matrix[x2][y2] == BLACK_ROOK or \
                chess_matrix[x2][y2] == BLACK_QUEEN or chess_matrix[x2][y2] == BLACK_PAWN:
            flag = False

    if flag:
        chess_matrix[x1][y1] = BLANK_SPACE
        chess_matrix[x2][y2] = WHITE_PAWN
        return flag


def initialize_chess(chess_matrix, x, y, player):
    for i in range(0, x):
        for j in range(0, y):
            chess_matrix[i][j] = BLANK_SPACE

    if player == 1:  # in the case when player is White and AI is Black
        chess_matrix[0][0] = BLACK_ROOK
        chess_matrix[0][1] = BLACK_KNIGHT
        chess_matrix[0][2] = BLACK_BISHOP
        chess_matrix[0][3] = BLACK_QUEEN
        chess_matrix[0][4] = BLACK_KING
        chess_matrix[0][5] = BLACK_BISHOP
        chess_matrix[0][6] = BLACK_KNIGHT
        chess_matrix[0][7] = BLACK_ROOK

        for i in range(8):
            chess_matrix[1][i] = BLACK_PAWN

        for i in range(8):
            chess_matrix[6][i] = WHITE_PAWN

        chess_matrix[7][0] = WHITE_ROOK
        chess_matrix[7][1] = WHITE_KNIGHT
        chess_matrix[7][2] = WHITE_BISHOP
        chess_matrix[7][3] = WHITE_QUEEN
        chess_matrix[7][4] = WHITE_KING
        chess_matrix[7][5] = WHITE_BISHOP
        chess_matrix[7][6] = WHITE_KNIGHT
        chess_matrix[7][7] = WHITE_ROOK

    else:  # in the case when player is Black and AI is White
        chess_matrix[7][0] = BLACK_ROOK
        chess_matrix[7][1] = BLACK_KNIGHT
        chess_matrix[7][2] = BLACK_BISHOP
        chess_matrix[7][3] = BLACK_KING
        chess_matrix[7][4] = BLACK_QUEEN
        chess_matrix[7][5] = BLACK_BISHOP
        chess_matrix[7][6] = BLACK_KNIGHT
        chess_matrix[7][7] = BLACK_ROOK

        for i in range(8):
            chess_matrix[6][i] = BLACK_PAWN

        for i in range(8):
            chess_matrix[1][i] = WHITE_PAWN

        chess_matrix[0][0] = WHITE_ROOK
        chess_matrix[0][1] = WHITE_KNIGHT
        chess_matrix[0][2] = WHITE_BISHOP
        chess_matrix[0][3] = WHITE_KING
        chess_matrix[0][4] = WHITE_QUEEN
        chess_matrix[0][5] = WHITE_BISHOP
        chess_matrix[0][6] = WHITE_KNIGHT
        chess_matrix[0][7] = WHITE_ROOK

    Print_Matrix(chess_matrix, x, y)


def check_mate(board, player, piece_white, piece_black):
    flag = True

    b = [copy.deepcopy(board) for i in range(8)]
    pi_w = [copy.deepcopy(piece_white) for i in range(8)]
    pi_b = [copy.deepcopy(piece_black) for i in range(8)]

    if player == 1:
        if (Move_King(b[0], pi_w[0].King[0], pi_w[0].King[1], pi_w[0].King[0] + 1, pi_w[0].King[1] + 1, player, pi_w[0],
                      pi_b[0]) or
                Move_King(b[1], pi_w[1].King[0], pi_w[1].King[1], pi_w[1].King[0] + 1, pi_w[1].King[1] - 1, player,
                          pi_w[1], pi_b[1]) or
                Move_King(b[2], pi_w[2].King[0], pi_w[2].King[1], pi_w[2].King[0] - 1, pi_w[2].King[1] + 1, player,
                          pi_w[2], pi_b[2]) or
                Move_King(b[3], pi_w[3].King[0], pi_w[3].King[1], pi_w[3].King[0] - 1, pi_w[3].King[1] - 1, player,
                          pi_w[3], pi_b[3]) or
                Move_King(b[4], pi_w[4].King[0], pi_w[4].King[1], pi_w[4].King[0], pi_w[4].King[1] + 1, player, pi_w[4],
                          pi_b[4]) or
                Move_King(b[5], pi_w[5].King[0], pi_w[5].King[1], pi_w[5].King[0], pi_w[5].King[1] - 1, player, pi_w[5],
                          pi_b[5]) or
                Move_King(b[6], pi_w[6].King[0], pi_w[6].King[1], pi_w[6].King[0] + 1, pi_w[6].King[1], player, pi_w[6],
                          pi_b[6]) or
                Move_King(b[7], pi_w[7].King[0], pi_w[7].King[1], pi_w[7].King[0] - 1, pi_w[7].King[1], player, pi_w[7],
                          pi_b[7])):
            flag = False

    else:
        if (Move_King(b[0], pi_b[0].King[0], pi_b[0].King[1], pi_b[0].King[0] + 1, pi_b[0].King[1] + 1, player, pi_w[0],
                      pi_b[0]) or
                Move_King(b[1], pi_b[1].King[0], pi_b[1].King[1], pi_b[1].King[0] + 1, pi_b[1].King[1] - 1, player,
                          pi_w[1], pi_b[1]) or
                Move_King(b[2], pi_b[2].King[0], pi_b[2].King[1], pi_b[2].King[0] - 1, pi_b[2].King[1] + 1, player,
                          pi_w[2], pi_b[2]) or
                Move_King(b[3], pi_b[3].King[0], pi_b[3].King[1], pi_b[3].King[0] - 1, pi_b[3].King[1] - 1, player,
                          pi_w[3], pi_b[3]) or
                Move_King(b[4], pi_b[4].King[0], pi_b[4].King[1], pi_b[4].King[0], pi_b[4].King[1] + 1, player, pi_w[4],
                          pi_b[4]) or
                Move_King(b[5], pi_b[5].King[0], pi_b[5].King[1], pi_b[5].King[0], pi_b[5].King[1] - 1, player, pi_w[5],
                          pi_b[5]) or
                Move_King(b[6], pi_b[6].King[0], pi_b[6].King[1], pi_b[6].King[0] + 1, pi_b[6].King[1], player, pi_w[6],
                          pi_b[6]) or
                Move_King(b[7], pi_b[7].King[0], pi_b[7].King[1], pi_b[7].King[0] - 1, pi_b[7].King[1], player, pi_w[7],
                          pi_b[7])):
            flag = False

    return flag


def select_maximum_value(chess_matrix_tree, value):
    max = math.inf
    index = None
    for i in range(0, len(value)):
        if value[i] < max:
            max = value[i]
            index = i
    return chess_matrix_tree[index]


def main():
    player = input("What color would you like to play as? (1 for White and 0 for Black): ")
    player = int(player)
    rows = 8
    cols = 8
    matrix = [[0 for i in range(cols)] for j in range(rows)]
    Black = Pieces(player, 0)
    White = Pieces(player, 1)
    initialize_chess(matrix, rows, cols, player)
    check_white = False
    check_black = False
    turn = player
    total_points_white = 0
    total_points_black = 0
    while True:
        points_white = 0
        points_black = 0
        flag = False
        null_val = 0
        print("---------------------------------------------------------------")
        print("Turn Of PLayer:- ", turn)
        if check_white or check_black:
            print("King is in check!")

        # os.system('cls')
        # print(chr(27) + "[2J")
        print(" ")

        if turn == 1:
            notation = input("Enter the notation: ")
            if notation[0:1] == "S":
                print("White Surrendered!\n\nBlack Wins!")
                break
            flag, points_white, null_val = make_move(matrix, notation, White, Black, turn, total_points_white)

            if check_attack(matrix, Black.King[0], Black.King[1], 0, White, Black):
                check_black = True
            else:
                check_black = False

            if check_attack(matrix, White.King[0], White.King[1], 1, White, Black):
                check_white = True
            else:
                check_white = False

        else:
            chess_matrix_tree, value = minimax(matrix, 0, White, Black)

            matrix = select_maximum_value(chess_matrix_tree, value)

            if check_attack(matrix, White.King[0], White.King[1], 1, White, Black):
                check_white = True
            else:
                check_white = False

            if check_attack(matrix, Black.King[0], Black.King[1], 0, White, Black):
                check_black = True
            else:
                check_black = False

        Print_Matrix(matrix, rows, cols)

        if check_white:
            if check_mate(matrix, 1, White, Black):
                print("Black wins!")
                break

        if check_black:
            if check_mate(matrix, 0, White, Black):
                print("White wins!")
                break

        if turn == 1 and flag:
            total_points_white = total_points_white + points_white
            print("Total Points Of White:- ", total_points_white)
            turn = 0
        else:
            total_points_black = total_points_black + points_black
            print("Total Points Of Black:- ", total_points_black)
            turn = 1


# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    main()
